Next samples 
	08_integration\01_dhtmlxgrid.html 
	08_integration\02_dhtmlxgrid_group.html
	08_integration\03_layout.html
requires external components ( dhtmlxgrid and dhtmlxwindow )

Its recommended to run samples through any kind of webserver.
