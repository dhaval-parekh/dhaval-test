<?php
$list_3rd[0]['name'] = 'WordPress';
$list_3rd[0]['url'] = 'wordpress-chat.html';
$list_3rd[1]['name'] = 'Joomla';
$list_3rd[1]['url'] = 'joomla-chat.html';
$list_3rd[2]['name'] = 'PunBB';
$list_3rd[2]['url'] = 'punbb-chat.html';

$list_3rd[3]['name'] = 'Drupal';
$list_3rd[3]['url'] = 'drupal-chat.html';
$list_3rd[4]['name'] = 'Phpbb';
$list_3rd[4]['url'] = 'phpbb_chat.html';
$list_3rd[5]['name'] = 'SMF';
$list_3rd[5]['url'] = 'smf-chat.html';

$list_3rd[6]['name'] = 'VBB';
$list_3rd[6]['url'] = 'vBulletin_chat.html';
$list_3rd[7]['name'] = 'Moodle';
$list_3rd[7]['url'] = 'moodle-chat.html';
$list_3rd[8]['name'] = 'IPB';
$list_3rd[8]['url'] = 'ipb_chat.html';

$list_3rd[9]['name'] = 'Phpfox';
$list_3rd[9]['url'] = 'phpfox-chat.html';
$list_3rd[10]['name'] = 'MyBB';
$list_3rd[10]['url'] = 'mybb-chat.html';
$list_3rd[11]['name'] = 'Phpnuke';
$list_3rd[11]['url'] = 'phpnuke_chat.html';

$list_3rd[12]['name'] = 'BuddyPress';
$list_3rd[12]['url'] = 'buddypress-chat.html';
$list_3rd[13]['name'] = 'Elgg';
$list_3rd[13]['url'] = 'elgg-chat.html';
$list_3rd[14]['name'] = 'Xoops';
$list_3rd[14]['url'] = 'xoops-chat.html';

$list_3rd[15]['name'] = 'Dolphin';
$list_3rd[15]['url'] = 'dolphin-chat.html';
$list_3rd[16]['name'] = 'Mambo';
$list_3rd[16]['url'] = 'mambo-chat.html';
$list_3rd[17]['name']= 'E107';
$list_3rd[17]['url']= 'e107-chat.html';

$list_3rd[18]['name']= 'Phpfusion';
$list_3rd[18]['url']= 'phpfusion-chat.html';
$list_3rd[19]['name'] = 'XMB';
$list_3rd[19]['url'] = 'xmb-chat.html';
$list_3rd[20]['name'] = 'YaBB';
$list_3rd[20]['url'] = 'yabb-chat.html';


$list_3rd[21]['name'] = 'UseBB';
$list_3rd[21]['url'] = 'usebb-chat.html';
$list_3rd[22]['name'] = 'Postnuke';
$list_3rd[22]['url'] = 'postnuke_chat.html';
$list_3rd[23]['name'] = 'Cpgnuke';
$list_3rd[23]['url'] = 'cpgnuke-chat.html';

$list_3rd[24]['name'] = 'IP_CMS';
$list_3rd[24]['url'] = 'ip-cms-chat.html';
$list_3rd[25]['name'] = 'OsDate';
$list_3rd[25]['url'] = 'osdate-chat';
$list_3rd[26]['name'] = 'ShareTronix';
$list_3rd[26]['url'] = 'sharetronix-chat';
?>