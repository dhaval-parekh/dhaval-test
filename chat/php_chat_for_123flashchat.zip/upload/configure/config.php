<?php
		$running_mode = 'free';
		$room_name = 'Lobby';
		?>