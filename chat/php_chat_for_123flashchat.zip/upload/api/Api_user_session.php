<?php
/*
simple code:

//code begin
session_start();
$username= $_SESSION[username];
$password= $_SESSION[password]; 
//code end
*/



$username= '';
$password='';
?>