<?php
/*
//simple code:

//code begin

function hash_pw($password){

$salt = "test";

return  md5($password.$salt);

}

$password_encrypt_function_name = "hash_pw";

//code end
*/


$password_encrypt_function_name = "";
?>