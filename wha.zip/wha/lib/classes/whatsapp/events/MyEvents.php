<?php
require 'AllEvents.php';

class MyEvents extends AllEvents
{
    /**
     * This is a list of all current events. Uncomment the ones you wish to listen to.
     * Every event that is uncommented - should then have a function below.
     * @var array
     */
	 private $notifyUrl = false;
    public $activeEvents = array(
        'onClose',
        'onCodeRegister',
        'onCodeRegisterFailed',
        'onCodeRequest',
        'onCodeRequestFailed',
        'onCodeRequestFailedTooRecent',
        'onConnect',
        'onConnectError',
        'onCredentialsBad',
        'onCredentialsGood',
        'onDisconnect',
        'onDissectPhone',
        'onDissectPhoneFailed',
        'onGetAudio',
        'onGetBroadcastLists',
        'onGetError',
        'onGetExtendAccount',
        'onGetGroupMessage',
        'onGetGroupParticipants',
        'onGetGroups',
        'onGetGroupsInfo',
        'onGetGroupsSubject',
        'onGetImage',
        'onGetLocation',
        'onGetMessage',
        'onGetNormalizedJid',
        'onGetPrivacyBlockedList',
        'onGetProfilePicture',
        'onGetReceipt',
        'onGetServerProperties',
        'onGetServicePricing',
        'onGetStatus',
        'onGetSyncResult',
        'onGetVideo',
        'onGetvCard',
        'onGroupCreate',
        'onGroupisCreated',
        'onGroupsChatCreate',
        'onGroupsChatEnd',
        'onGroupsParticipantsAdd',
        'onGroupsParticipantsPromote',
        'onGroupsParticipantsRemove',
        'onLoginFailed',
        'onLoginSuccess',
        'onAccountExpired',
        'onMediaMessageSent',
        'onMediaUploadFailed',
        'onMessageComposing',
        'onMessagePaused',
        'onMessageReceivedClient',
        'onMessageReceivedServer',
        'onPaidAccount',
        'onPing',
        'onPresenceAvailable',
        'onPresenceUnavailable',
        'onProfilePictureChanged',
        'onProfilePictureDeleted',
        'onSendMessage',
        'onSendMessageReceived',
        'onSendPong',
        'onSendPresence',
        'onSendStatusUpdate',
        'onStreamError',
        'onUploadFile',
        'onUploadFileFailed',
    );
	
	// helpers Functions
	private function notifyServer($request = false){
		$this->event_log($request);
		if(! $this->notifyUrl){
			return false;
		}
		if($request){
			$request = json_encode($request);
		}
		$url = 'http://leclient.ciphersoul.com/index.php/api/index/';
		$url = $this->notifyUrl;
		$header = array("Content-Type: application/json","access-control-allow-origin: *");
		// All API
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS,$request);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$response  = curl_exec($ch);
		curl_close($ch);
		$this->event_log($response);
		
		return $response;
	}
	
	private function event_log($text){
		if(is_array($text)){ $text = 'Array => '.json_encode($text); }
		
		$file_name = 'event_log.txt';
		$file = fopen($file_name, "a");
		$cur_Date = date('Y-m-d H:i:s');
		$text = $cur_Date.' "'.$text.'"; '.PHP_EOL;
		fwrite($file, $text);
		
	}
	
	public function setNotifyUrl($url){
		if(! empty($url)){
			$this->notifyUrl = $url;
			return true;
		}
		return false;
	}
	
	
	// Events Listing
	public function onCallReceived($mynumber, $from, $id, $notify, $time, $callId) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'from'=>$from,
								'id'=>$id,
								'notify'=>$notify,
								'time'=>$time,
								'callId'=>$callId,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onClose($mynumber, $error) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'error'=>$error,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onCodeRegister($mynumber, $login, $password, $type, $expiration, $kind, $price, $cost, $currency, $price_expiration) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'login'=>$login,
								'password'=>$password,
								'type'=>$type,
								'expiration'=>$expiration,
								'kind'=>$kind,
								'price'=>$price,
								'cost'=>$cost,
								'currency'=>$currency,
								'price_expiration'=>$price_expiration,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onCodeRegisterFailed($mynumber, $status, $reason, $retry_after) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'status'=>$status,
								'reason'=>$reason,
								'retry_after'=>$retry_after,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onCodeRequest($mynumber, $method, $length) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'method'=>$method,
								'length'=>$length,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onCodeRequestFailed($mynumber, $method, $reason, $param) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'method'=>$method,
								'reason'=>$reason,
								'param'=>$param,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onCodeRequestFailedTooRecent($mynumber, $method, $reason, $retry_after) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'method'=>$method,
								'reason'=>$reason,
								'retry_after'=>$retry_after,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onCodeRequestFailedTooManyGuesses($mynumber, $method, $reason, $retry_after) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'method'=>$method,
								'reason'=>$reason,
								'retry_after'=>$retry_after,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}
	
	public function onConnectError($mynumber, $socket) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'socket'=>$socket,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onCredentialsBad($mynumber, $status, $reason) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'status'=>$status,
								'reason'=>$reason,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onCredentialsGood($mynumber, $login, $password, $type, $expiration, $kind, $price, $cost, $currency, $price_expiration) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'login'=>$login,
								'password'=>$password,
								'type'=>$type,
								'expiration'=>$expiration,
								'kind'=>$kind,
								'price'=>$price,
								'cost'=>$cost,
								'currency'=>$currency,
								'price_expiration'=>$price_expiration,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}
	
	public function onDissectPhone($mynumber, $phonecountry, $phonecc, $phone, $phonemcc, $phoneISO3166, $phoneISO639, $phonemnc) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'phonecountry'=>$phonecountry,
								'phonecc'=>$phonecc,
								'phone'=>$phone,
								'phonemcc'=>$phonemcc,
								'phoneISO3166'=>$phoneISO3166,
								'phoneISO639'=>$phoneISO639,
								'phonemnc'=>$phonemnc,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onDissectPhoneFailed($mynumber) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onGetBroadcastLists($mynumber, $broadcastLists){
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'broadcastLists'=>$broadcastLists,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onGetError($mynumber, $from, $id, $data, $errorType = null) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'from'=>$from,
								'id'=>$id,
								'data'=>$data,
								'errorType'=>$errorType,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onGetExtendAccount($mynumber, $kind, $status, $creation, $expiration) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'kind'=>$kind,
								'status'=>$status,
								'creation'=>$creation,
								'expiration'=>$expiration,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onGetFeature($mynumber, $from, $encrypt) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'from'=>$from,
								'encrypt'=>$encrypt,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onGetGroupMessage($mynumber, $from_group_jid, $from_user_jid, $id, $type, $time, $name, $body) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'from_group_jid'=>$from_group_jid,
								'from_user_jid'=>$from_user_jid,
								'id'=>$id,
								'type'=>$type,
								'time'=>$time,
								'name'=>$name,
								'body'=>$body,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onGetGroups($mynumber, $groupList) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'groupList'=>$groupList,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onGetGroupV2Info( $mynumber, $group_id, $creator, $creation, $subject, $participants, $admins, $fromGetGroup ){
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'group_id'=>$group_id,
								'creator'=>$creator,
								'creation'=>$creation,
								'subject'=>$subject,
								'participants'=>$participants,
								'admins'=>$admins,
								'fromGetGroup'=>$fromGetGroup,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onGetGroupsSubject($mynumber, $group_jid, $time, $author, $name, $subject) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'group_jid'=>$group_jid,
								'time'=>$time,
								'author'=>$author,
								'name'=>$name,
								'subject'=>$subject,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}
	
	
	public function onGetGroupImage($mynumber, $from_group_jid, $from_user_jid, $id, $type, $time, $name, $size, $url, $file, $mimeType, $fileHash, $width, $height, $preview, $caption) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'from_group_jid'=>$from_group_jid,
								'from_user_jid'=>$from_user_jid,
								'id'=>$id,
								'type'=>$type,
								'time'=>$time,
								'name'=>$name,
								'size'=>$size,
								'url'=>$url,
								'file'=>$file,
								'mimeType'=>$mimeType,
								'fileHash'=>$fileHash,
								'width'=>$width,
								'height'=>$height,
								'preview'=>$preview,
								'caption'=>$caption,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onGetGroupVideo($mynumber, $from_group_jid, $from_user_jid, $id, $type, $time, $name, $url, $file, $size, $mimeType, $fileHash, $duration, $vcodec, $acodec, $preview, $caption) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'from_group_jid'=>$from_group_jid,
								'from_user_jid'=>$from_user_jid,
								'id'=>$id,
								'type'=>$type,
								'time'=>$time,
								'name'=>$name,
								'url'=>$url,
								'file'=>$file,
								'size'=>$size,
								'mimeType'=>$mimeType,
								'fileHash'=>$fileHash,
								'duration'=>$duration,
								'vcodec'=>$vcodec,
								'acodec'=>$acodec,
								'preview'=>$preview,
								'caption'=>$caption,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onGetLocation($mynumber, $from, $id, $type, $time, $name, $author, $longitude, $latitude, $url, $preview, $fromJID_ifGroup = null) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'from'=>$from,
								'id'=>$id,
								'time'=>$time,
								'name'=>$name,
								'author'=>$author,
								'longitude'=>$longitude,
								'latitude'=>$latitude,
								'url'=>$url,
								'preview'=>$preview,
								'fromJID_ifGroup'=>$fromJID_ifGroup,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onGetNormalizedJid($mynumber, $data) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'data'=>$data,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onGetPrivacyBlockedList($mynumber, $data) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'data'=>$data,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}
	
	
	public function onGetProfilePicture($mynumber, $from, $type, $data) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'from'=>$from,
								'type'=>$type,
								'data'=>$data,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onGetReceipt($from, $id, $offline, $retry) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'from'=>$from,
								'id'=>$id,
								'offline'=>$offline,
								'retry'=>$retry,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onGetServerProperties($mynumber, $version, $props) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'version'=>$version,
								'props'=>$props,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onGetServicePricing($mynumber, $price, $cost, $currency, $expiration) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'price'=>$price,
								'cost'=>$cost,
								'currency'=>$currency,
								'expiration'=>$expiration,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onGetStatus($mynumber, $from, $requested, $id, $time, $data) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'from'=>$from,
								'requested'=>$requested,
								'id'=>$id,
								'time'=>$time,
								'data'=>$data,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}
	
	
	public function onGroupCreate($mynumber, $groupId) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'groupId'=>$groupId,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onGroupisCreated($mynumber, $creator, $gid, $subject, $admin, $creation, $members = array()) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'creator'=>$creator,
								'gid'=>$gid,
								'subject'=>$subject,
								'admin'=>$admin,
								'creation'=>$creation,
								'members'=>$members,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onGroupsChatCreate($mynumber, $gid) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'gid'=>$gid,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onGroupsChatEnd($mynumber, $gid) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'gid'=>$gid,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onGroupsParticipantsAdd($mynumber, $groupId, $jid) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'groupId'=>$groupId,
								'jid'=>$jid,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}
	
	
	public function onGroupsParticipantChangedNumber($mynumber, $groupId, $time, $oldNumber, $notify, $newNumber) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'groupId'=>$groupId,
								'time'=>$time,
								'oldNumber'=>$oldNumber,
								'notify'=>$notify,
								'newNumber'=>$newNumber,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onGroupsParticipantsPromote($myNumber, $groupJID, $time, $issuerJID, $issuerName, $promotedJIDs = array()) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'groupJID'=>$groupJID,
								'time'=>$time,
								'issuerJID'=>$issuerJID,
								'issuerName'=>$issuerName,
								'promotedJIDs'=>$promotedJIDs,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onGroupsParticipantsRemove($mynumber, $groupId, $jid) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'groupId'=>$groupId,
								'jid'=>$jid,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onLoginFailed($mynumber, $data) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'data'=>$data,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onLoginSuccess($mynumber, $kind, $status, $creation, $expiration) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'kind'=>$kind,
								'status'=>$status,
								'creation'=>$creation,
								'expiration'=>$expiration,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}
	
	
	public function onAccountExpired($mynumber, $kind, $status, $creation, $expiration ){
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'kind'=>$kind,
								'status'=>$status,
								'creation'=>$creation,
								'expiration'=>$expiration,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onMediaMessageSent($mynumber, $to, $id, $filetype, $url, $filename, $filesize, $filehash, $caption, $icon) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'to'=>$to,
								'id'=>$id,
								'filetype'=>$filetype,
								'url'=>$url,
								'filename'=>$filename,
								'filesize'=>$filesize,
								'filehash'=>$filehash,
								'caption'=>$caption,
								'icon'=>$icon,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onMediaUploadFailed($mynumber, $id, $node, $messageNode, $statusMessage) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'id'=>$id,
								'node'=>$node,
								'messageNode'=>$messageNode,
								'statusMessage'=>$statusMessage,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onMessageComposing($mynumber, $from, $id, $type, $time) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'from'=>$from,
								'id'=>$id,
								'type'=>$type,
								'time'=>$time,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onMessagePaused($mynumber, $from, $id, $type, $time) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'from'=>$from,
								'id'=>$id,
								'type'=>$type,
								'time'=>$time,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}
	
	
	public function onMessageReceivedClient($mynumber, $from, $id, $type, $time, $participant) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'from'=>$from,
								'id'=>$id,
								'type'=>$type,
								'time'=>$time,
								'participant'=>$participant,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onMessageReceivedServer($mynumber, $from, $id, $type, $time) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'from'=>$from,
								'id'=>$id,
								'type'=>$type,
								'time'=>$time,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onNumberWasAdded($mynumber, $jid) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'jid'=>$jid,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onNumberWasRemoved($mynumber, $jid) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'jid'=>$jid,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onNumberWasUpdated($mynumber, $jid) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'jid'=>$jid,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}
	
	
	public function onPaidAccount($mynumber, $author, $kind, $status, $creation, $expiration) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'author'=>$author,
								'kind'=>$kind,
								'status'=>$status,
								'creation'=>$creation,
								'expiration'=>$expiration,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onPaymentRecieved($mynumber, $kind, $status, $creation, $expiration) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'kind'=>$kind,
								'status'=>$status,
								'creation'=>$creation,
								'expiration'=>$expiration,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onPing($mynumber, $id) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'id'=>$id,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onPresenceAvailable($mynumber, $from) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'from'=>$from,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onPresenceUnavailable($mynumber, $from, $last) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'from'=>$from,
								'last'=>$last,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}
	
	
	public function onProfilePictureChanged($mynumber, $from, $id, $time) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'from'=>$from,
								'id'=>$id,
								'time'=>$time,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onProfilePictureDeleted($mynumber, $from, $id, $time) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'from'=>$from,
								'id'=>$id,
								'time'=>$time,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onSendMessage($mynumber, $target, $messageId, $node) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'target'=>$target,
								'messageId'=>$messageId,
								'node'=>$node,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onSendMessageReceived($mynumber, $id, $from, $type) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'id'=>$id,
								'from'=>$from,
								'type'=>$type,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onSendPong($mynumber, $msgid) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'msgid'=>$msgid,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}
	
	
	public function onSendPresence($mynumber, $type, $name ) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'type'=>$type,
								'name'=>$name,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onSendStatusUpdate($mynumber, $txt ) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'txt'=>$txt,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onStreamError($data) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'data'=>$data,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onWebSync($mynumber, $from, $id, $syncData, $code, $name) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'from'=>$from,
								'id'=>$id,
								'syncData'=>$syncData,
								'code'=>$code,
								'name'=>$name,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}
	
	
	public function onConnect($mynumber, $socket){
		$this->event_log('==========================================================================');
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'socket'=>$socket,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onDisconnect($mynumber, $socket){
		
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'socket'=>$socket,
							),
					);
		$response = $this->notifyServer($request);
		$this->event_log('==========================================================================');
		return $response;
	}

	public function onGetMessage($mynumber, $from, $id, $type, $time, $name, $body) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'from'=>$from,
								'id'=>$id,
								'type'=>$type,
								'time'=>$time,
								'name'=>$name,
								'body'=>$body,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onGetAudio($mynumber, $from, $id, $type, $time, $name, $size, $url, $file, $mimeType, $fileHash, $duration, $acodec, $fromJID_ifGroup = null) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'from'=>$from,
								'id'=>$id,
								'type'=>$type,
								'time'=>$time,
								'name'=>$name,
								'size'=>$size,
								'url'=>$url,
								'file'=>$file,
								'mimeType'=>$mimeType,
								'fileHash'=>$fileHash,
								'duration'=>$duration,
								'acodec'=>$acodec,
								'fromJID_ifGroup'=>$fromJID_ifGroup,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onGetImage($mynumber, $from, $id, $type, $time, $name, $size, $url, $file, $mimeType, $fileHash, $width, $height, $preview, $caption) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'from'=>$from,
								'id'=>$id,
								'type'=>$type,
								'time'=>$time,
								'name'=>$name,
								'size'=>$size,
								'url'=>$url,
								'file'=>$file,
								'mimeType'=>$mimeType,
								'fileHash'=>$fileHash,
								'width'=>$width,
								'height'=>$height,
								'preview'=>$preview,
								'caption'=>$caption,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onGetVideo($mynumber, $from, $id, $type, $time, $name, $url, $file, $size, $mimeType, $fileHash, $duration, $vcodec, $acodec, $preview, $caption) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'from'=>$from,
								'id'=>$id,
								'type'=>$type,
								'time'=>$time,
								'name'=>$name,
								'url'=>$url,
								'file'=>$file,
								'size'=>$size,
								'mimeType'=>$mimeType,
								'fileHash'=>$fileHash,
								'duration'=>$duration,
								'vcodec'=>$vcodec,
								'acodec'=>$acodec,
								'preview'=>$preview,
								'caption'=>$caption,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	public function onGetvCard($mynumber, $from, $id, $type, $time, $name, $vcardname, $vcard, $fromJID_ifGroup = null) {
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'mynumber'=>$mynumber,
								'from'=>$from,
								'id'=>$id,
								'type'=>$type,
								'time'=>$time,
								'name'=>$name,
								'vcardname'=>$vcardname,
								'vcard'=>$vcard,
								'fromJID_ifGroup'=>$fromJID_ifGroup,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}

	
	public function onGetSyncResult($result) {
		// print_r($result);
		$request = array(
						'event' => __FUNCTION__,
						'args' => array(
								'result'=>$result,
							),
					);
		$response = $this->notifyServer($request);
		return $response;
	}
	
	
}
