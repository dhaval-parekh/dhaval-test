<?php
interface ECPublicKey {
    public function serialize ();
    public function getType ();
}
