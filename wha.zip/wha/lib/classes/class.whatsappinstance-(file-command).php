<?php
set_time_limit(0);
ini_set('max_execution_time', 0); //0=NOLIMIT

class WhatsappInstance {

	private $phone;
	private $password;
	private $name;
	private $notifyUrl;
	private $token;
	private $login;

	private $host;
	private $port;
	private $socket;
	private $debug;

	private $whatsapp;
	private $event;

	public function __construct($phone,$password,$name,$url,$port,$token,$debug = false){
		$this->phone = $phone;
		$this->name = $name;
		$this->notifyUrl = $url;
		$this->password = $password;
		$this->token = $token;
		
		$this->debug = $debug;
		$this->host = HOST;
		$this->port = $port;
		$this->socket = false;

		$this->login = 0;

		$this->whatsapp = new WhatsProt($this->phone,$this->name,$this->debug);
		$this->event = new MyEvents($this->whatsapp);
	}
	
	public function index(){
		$this->whatsapp->connect();
	}
	
	private function ping_start($url){
		if(! isset($url)){ return false; }
		$output = shell_exec('crontab -l');
		echo $output;
		file_put_contents('/tmp/crontab.txt', $output.'* * * * * wget '.$url.' '.PHP_EOL);
		echo exec('crontab /tmp/crontab.txt');
	}
	private function ping_stop(){
		echo exec('crontab -r');
	}
	
	public function login(){
		
		try{
			$url = API_URL.'ping/?token='.$this->token;
			//$this->ping_start($url);
			
			$this->event->setEventsToListenFor($this->event->activeEvents);
			
			$this->event->setNotifyUrl($this->notifyUrl);
			
			$this->whatsapp->connect();
			$this->whatsapp->loginWithPassword($this->password);
			
			$this->login = 1;
			/*$this->whatsapp->eventManager()->bind('onGetSyncResult', 'onSyncResult');
			$this->whatsapp->eventManager()->bind('onGetRequestLastSeen', 'onGetRequestLastSeen');
			$this->whatsapp->eventManager()->bind('onPresenceAvailable', 'onPresenceAvailable');
			$this->whatsapp->eventManager()->bind('onPresenceUnavailable', 'onPresenceUnavailable');
			$this->whatsapp->eventManager()->bind('onGetImage', 'onGetImage');
			$this->whatsapp->eventManager()->bind('onGetVideo', 'onGetVideo');
			$this->whatsapp->eventManager()->bind('onGetAudio', 'onGetAudio');
			$this->whatsapp->eventManager()->bind("onGetMessage", "onMessage");*/
			
			$this->whatsapp->sendGetPrivacyBlockedList(); // Get our privacy list
			$this->whatsapp->sendGetClientConfig();
			$this->whatsapp->sendGetServerProperties();
			$this->whatsapp->sendGetGroups();
			$this->whatsapp->sendGetBroadcastLists();

		}catch(Exception $e){
			display($e);
			return false;
			
		}
		return true;
	}
	
	public function logout(){
		if($this->login == 1){
			$this->whatsapp->sendMessage('919909208175', 'Exit');
			//$this->ping_stop();
			$this->whatsapp->disconnect();
		}
		return true;
	}
	
	public function poll(){
		if($this->login == 1){
			$count = 0;
			while($this->whatsapp->pollMessage());
		}
	}
	
	public function sendSync($contacts = array()){
		$this->whatsapp->sendSync($contacts);
		
		/*$this->whatsapp->sendGetStatuses($contacts);
		foreach($contacts as $contact){
			$this->whatsapp->sendPresenceSubscription($contact);
			$this->whatsapp->sendGetProfilePicture($contact);
		}*/
	}
	
	private function sendMessage($to,$message,$message_type){
		switch($message_type){
			case 2: // image
					//$this->whatsapp->sendMessageImage($to, $filepath, false, $fsize, $fhash, $caption);
					$response = $this->whatsapp->sendMessageImage($to,$message);

				break;
			case 3:	// audio
					//$this->whatsapp->sendMessageAudio($target, $filepath, false, $fsize, $fhash);
					$response = $this->whatsapp->sendMessageAudio($to,$message);
					
				break;
			case 4: // video
					$response = $this->whatsapp->sendMessageVideo($to,$message);
				break;
			case 1: // Simple text message
			default:	
					$response = $this->whatsapp->sendMessage($to,$message );
				break;
		}

		return $response;
	}
	
	public function run(){
		
		//$this->socket = socket_create(AF_INET, SOCK_STREAM, 0) or die("Could not create socket\n");	
		//$result = socket_bind($this->socket, $this->host, $this->port) or die("Could not bind to socket\n");

		$count = 0;	
		system_log('Start => '.$this->phone.' => '.date('Y-m-d H:i:s'));
		while(true){
			//$count++;
			
			$input = false;
			$log = $this->name.' => '.$this->port.' => '.$count;
			/*
			system_log($log);
			$this->whatsapp->sendMessage('919909208175', $log);
			$result = socket_listen($this->socket, 3) or die("Could not set up socket listener\n");
			system_log('listen over');
			$spawn = socket_accept($this->socket) or die("Could not accept incoming connection\n");
			system_log('accepted');
			socket_set_timeout($spawn, 0, 100);
			$input = socket_read($spawn, 2048) or die("Could not read input\n");
			system_log('read complater');
			*/
			$input = file_get_contents(DIR_WHATSAPP.$this->phone);
			$file = fopen(DIR_WHATSAPP.$this->phone,'w');
			fwrite($file,'');
			fclose($file);
			$response = array('status'=>201);
			if(! ($input && (!empty($input)) &&  is_array(json_decode($input,true))) ){
				//continue;	
			}
			
			$input = json_decode($input,true);
			system_log($input);
			if(! (isset($input['command']) && (! empty($input['command']))) ){
				
				$input['command'] = false;
				//continue;
			}
			
			$valid_flag = false;
			$command = trim(strtolower($input['command']));
				switch($command){
					case 'login':	
							$this->login();
							$valid_flag = true;
						break;
					case 'logout':
							if($this->logout()){
								$payload = 'loged out';
								return true; 
							}
						break;
					case 'die':
							$this->logout();
							die('Die');
						break;
					case 'type':
							$this->whatsapp->sendMessageComposing($input['to']);
							$valid_flag = true;
						break;
					case 'pause':
							$this->whatsapp->sendMessagePaused($input['to']);
							$valid_flag = true;
						break;
					case 'send':
							$payload = $this->sendMessage($input['to'], $input['message'], $input['messagetype']);
							//$payload = $this->whatsapp->sendMessage($input['to'], $input['message']);
							//system_log('message sent to '.$input['to'].' => '.$input['message']);		
							$valid_flag = true;
						break;
					case 'sync':
							
							$contacts = $input['contacts'];
							$contacts = array_unique($contacts);
							//$this->sendMessage('919909208175', 'sync', 1);
							$this->sendSync($contacts);
							$valid_flag = true;
						break;
					case 'poll':
					case 'ping':
					default:
							$this->whatsapp->sendPing();
							while($this->poll());
							//$valid_flag = true;	
						break;	
				}	

			if( $valid_flag){
				$response['status'] = 200;
				$response['message'] = 'ok';
				$response['payload'] = isset($payload)?$payload:true;
				$output = json_encode($response);
				
				system_log('command : '.$command);
				//socket_write($spawn, $output, strlen ($output)) or die("Could not write output\n"); 
				if($command == 'logout'){
					break;	
				}else{
					//sleep(1);
				}
			}
			$valid_flag = false;
		}// while close
		//return	$this->logout();
		system_log('Stop => '.$this->phone.' => '.date('Y-m-d H:i:s'));
		system_log('=================================================================');
		return true;
		//socket_close($spawn);
		//socket_close($this->socket);
	}
}


class ProcessNode
{
    protected $wp = false;
    protected $target = false;

    public function __construct($wp, $target)
    {
        $this->wp = $wp;
        $this->target = $target;
    }

    public function process($node)
    {
        if ($node->getAttribute("type") == 'text')
        {
            $text = $node->getChild('body');
            $text = $text->getData();
            $number = ExtractNumber($node->getAttribute("from"));
            //$nickname = findNicknameByPhone($number);
			$nickname = 'Dhaval';
			display($text);
           /* echo "<br> ".$number.": ".$text." @ ".date('h:i P')."<br>";*/
        }

    }
}
