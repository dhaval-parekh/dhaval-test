<?php
set_time_limit(0);
ini_set('max_execution_time', 0); //0=NOLIMIT

class WhatsappInstance {

	private $phone;
	private $password;
	private $name;
	private $notifyUrl;
	private $token;
	private $login;

	private $host;
	private $port;
	private $socket;
	private $debug;

	private $whatsapp;
	private $event;
	
	private $callback_url;
	public function __construct($phone,$password,$name,$url,$port,$token,$debug = false){
		$this->phone = $phone;
		$this->name = $name;
		$this->notifyUrl = $url;
		$this->password = $password;
		$this->token = $token;
		
		$this->debug = $debug;
		$this->host = HOST;
		$this->port = $port;
		$this->socket = false;
		$this->callback_url = BASE_URL."api/ping.php?token=".$this->token;
		$this->login = 0;

		$this->whatsapp = new WhatsProt($this->phone,$this->name,$this->debug);
		$this->event = new MyEvents($this->whatsapp);
	}
	
	public function index(){
		$this->whatsapp->connect();
	}
	
	private function ping_start(){
		if(! isset($this->callback_url)){ return false; }
		
		//$output = shell_exec('crontab -l');
		//file_put_contents('/tmp/crontab.txt', $output.'* * * * * wget '.$this->callback_url.' '.PHP_EOL);
		//exec('crontab /tmp/crontab.txt');
		
	}
	private function ping_stop(){
		//exec('crontab -r');
	}
	
	public function login(){
		
		try{
			$this->event->setEventsToListenFor($this->event->activeEvents);
			
			$this->event->setNotifyUrl($this->notifyUrl);
			
			$this->whatsapp->connect();
			$this->whatsapp->loginWithPassword($this->password);
			$this->ping_start(); // start Cron
			$this->login = 1;
			/*$this->whatsapp->eventManager()->bind('onGetSyncResult', 'onSyncResult');
			$this->whatsapp->eventManager()->bind('onGetRequestLastSeen', 'onGetRequestLastSeen');
			$this->whatsapp->eventManager()->bind('onPresenceAvailable', 'onPresenceAvailable');
			$this->whatsapp->eventManager()->bind('onPresenceUnavailable', 'onPresenceUnavailable');
			$this->whatsapp->eventManager()->bind('onGetImage', 'onGetImage');
			$this->whatsapp->eventManager()->bind('onGetVideo', 'onGetVideo');
			$this->whatsapp->eventManager()->bind('onGetAudio', 'onGetAudio');
			$this->whatsapp->eventManager()->bind("onGetMessage", "onMessage");*/
			
			$this->whatsapp->sendGetPrivacyBlockedList(); // Get our privacy list
			$this->whatsapp->sendGetClientConfig();
			$this->whatsapp->sendGetServerProperties();
			$this->whatsapp->sendGetGroups();
			$this->whatsapp->sendGetBroadcastLists();

		}catch(Exception $e){
			//display($e);
			return false;
			
		}
		return true;
	}
	
	public function logout(){
		if($this->login == 1){
			$payload = $this->sendMessage('919909208175', 'Exit',1);
			$this->whatsapp->disconnect();
			$this->ping_stop();
		}
		return true;
	}
	
	public function poll(){
		if($this->login == 1){
			while($this->whatsapp->pollMessage());
		}
		return true;
	}
	
	public function sendSync($contacts = array()){
		$this->whatsapp->sendSync($contacts);
		
		/*$this->whatsapp->sendGetStatuses($contacts);
		foreach($contacts as $contact){
			$this->whatsapp->sendPresenceSubscription($contact);
			$this->whatsapp->sendGetProfilePicture($contact);
		}*/
	}
	
	private function sendMessage($to,$message,$message_type = 1){
		switch($message_type){
			case 2: // image
					//$this->whatsapp->sendMessageImage($to, $filepath, false, $fsize, $fhash, $caption);

					$response = $this->whatsapp->sendMessageImage($to,$message);
					
				break;
			case 3:	// audio
					//$this->whatsapp->sendMessageAudio($target, $filepath, false, $fsize, $fhash);
					$response = $this->whatsapp->sendMessageAudio($to,$message);
					
				break;
			case 4: // video
					$response = $this->whatsapp->sendMessageVideo($to,$message);
				break;
			case 1: // Simple text message
			default:	
					//$payload = $this->whatsapp->sendMessageComposing($to);
					//$time = ceil(strlen($message)/25); 
					//sleep($time);
					//$payload = $this->whatsapp->sendMessagePaused($to);
					$response = $this->whatsapp->sendMessage($to,$message );

				break;
		}

		return $response;
	}

	private function handle_error($error = false){
		if(! $error){
			$error = 'Undefined Error';
		}
		$payload = $this->sendMessage('919909208175',$error,1);
		$this->logout();
		socket_close($this->socket);
			
		header('Content-type: application/json');
		$response = array('status'=>610,'message'=>$error);
		socket_close($this->socket);
		return $response;
		//die(json_encode($response));
	}	
	
	public function run(){
		
		$this->socket = socket_create(AF_INET, SOCK_STREAM, 0) or  $this->handle_error("Could not create socket\n");	
		$result = socket_bind($this->socket, $this->host, $this->port) or $this->handle_error("Could not bind to socket\n");

		$count = 0;	
		system_log('=================================================================');
		system_log('Start => '.$this->phone.' => '.date('Y-m-d H:i:s'));
		while(true){
			$input = false;
			
			$result = socket_listen($this->socket, 3) or $this->handle_error("Could not set up socket listener\n");
			//system_log('listen over');
			$spawn = socket_accept($this->socket) or $this->handle_error("Could not accept incoming connection\n");
			//system_log('accepted');
			//socket_set_timeout($spawn, 0 , 100); // 
			$input = socket_read($spawn, 100000) or $this->handle_error("Could not read input\n");
			//system_log('read complate');
			
			//$input = file_get_contents(DIR_WHATSAPP.$this->phone);
			//$file = fopen(DIR_WHATSAPP.$this->phone,'w');
			//fwrite($file,'');
			//fclose($file);
			$response = array('status'=>201);
			if(! ($input && (!empty($input)) &&  is_array(json_decode($input,true))) ){
				//continue;	
			}
			
			$input = json_decode($input,true);
			system_log($input);
			$count++;

			if(! (isset($input['command']) && (! empty($input['command']))) ){
				$input['command'] = false;
				//continue;
			}
			
			
			$valid_flag = false;
			$command = trim(strtolower($input['command']));
			$log = $this->name.' => '.$this->port.' => '.$count.' => '.$input['command'];
			//$payload = $this->sendMessage('919909208175', $log, 1);
			system_log($log);
			
				switch($command){
					case 'login':	
							$payload = $this->login();
							$valid_flag = true;
						break;
					case 'logout':
							$payload = $this->logout();
							if($payload){
								$valid_flag = true;
							}
						break;
					case 'die':
							$payload = $this->logout();
							die('Die');
						break;
					case 'type':
							$payload = $this->whatsapp->sendMessageComposing($input['to']);
							$valid_flag = true;
						break;
					case 'pause':
							$payload = $this->whatsapp->sendMessagePaused($input['to']);
							$valid_flag = true;
						break;
					case 'send':
							$payload = $this->sendMessage($input['to'], $input['message'], $input['messagetype']);
							$valid_flag = true;
						break;
					case 'sync':
							
							$contacts = $input['contacts'];
							$contacts = array_unique($contacts);
							$payload = $this->sendSync($contacts);
							$valid_flag = true;
						break;
					case 'poll':
							$this->poll();
							$payload = true;
							$valid_flag = true;	
							break;
					case 'ping':
					default:
							$payload = $this->whatsapp->sendPing();
							//$this->poll();
							$valid_flag = true;	
						break;	
				}	

			if( $valid_flag){
				$response['status'] = 200;
				$response['message'] = 'ok';
				$response['payload'] = isset($payload)? $payload:true;
				system_log($response);
				//$response = isset($payload)?$payload:true;
				if(isset($payload)){
					if(! (is_array($payload) || is_object($payload) )){
						$payload = mysql_real_escape_string($payload);
					}
					$response = $payload;
				}else{
					$response = true;
				}

				$output = json_encode($response);
				
				socket_write($spawn, $output, strlen ($output)) or $this->handle_error("Could not write output\n"); 
				if($command == 'logout'){
					sleep(1);
					break;
				}
			}
			socket_close($spawn);
			$valid_flag = false;
		}// while close
		system_log('Stop => '.$this->phone.' => '.date('Y-m-d H:i:s'));
		system_log('=================================================================');
		
		socket_close($this->socket);
		return true;
		
	}
}


class ProcessNode
{
    protected $wp = false;
    protected $target = false;

    public function __construct($wp, $target)
    {
        $this->wp = $wp;
        $this->target = $target;
    }

    public function process($node)
    {
        if ($node->getAttribute("type") == 'text')
        {
            $text = $node->getChild('body');
            $text = $text->getData();
            $number = ExtractNumber($node->getAttribute("from"));
            //$nickname = findNicknameByPhone($number);
			$nickname = 'Dhaval';
			display($text);
           /* echo "<br> ".$number.": ".$text." @ ".date('h:i P')."<br>";*/
        }

    }
}
