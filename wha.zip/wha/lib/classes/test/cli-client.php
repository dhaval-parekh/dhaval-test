<?php

define('HOST','127.0.0.1');
$host = HOST;

$port = 5353;

$message = array(	//'command'=>'login',
				//'command'=>'logout',
				'command'=>'type',
				//'command'=>'pause',
				'command'=>'send',
				'command'=>'logout',
				//'command'=>'ping',
				//'phone'=>'919909208175',
				'to'=>'919909208175',
				//'to'=>'919228220275',				
				'message' => 'http://whatsapp.ciphersoul.com/uploads/sample.mp3',
				'messagetype' => '1',
			);
$message = json_encode($message);


echo "Message To server :".$message."<br> \n";

// create socket
$socket = socket_create(AF_INET, SOCK_STREAM, 0) or die("Could not create socket\n");

// connect to server
$result = socket_connect($socket, $host, $port) or die("Could not connect to server\n");  

// send string to server
socket_write($socket, $message, strlen($message)) or die("Could not send data to server\n");
// get server response
$result = socket_read($socket, 2048) or die("Could not read server response\n");
echo "<br>Reply From Server  :".$result.'<br>\n';
// close socket
socket_close($socket);
echo 'closed\n';

