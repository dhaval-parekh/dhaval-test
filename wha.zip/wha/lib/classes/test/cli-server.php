<?php
define('HOST','127.0.0.1');
error_reporting(-1 & ~E_DEPRECATED);
require_once('../whatsapp/whatsprot.class.php');
require_once('../whatsapp/events/MyEvents.php');
require_once('../class.whatsappinstance-1.php');

define('BASE_URL', 'http://localhost/whatsapp/');
define('INDEX', 'index.php');
define('API_URL', BASE_URL.INDEX.'/'.'api/');
function system_log($text){
	$file_name = 'system_log.txt';
	$file = fopen($file_name, "a");
	$cur_Date = date('Y-m-d H:i:s');
	//$backtrack = debug_backtrace();
	//$function = $backtrack[count($backtrack)-2];
	//$location = 'File = "'.__FILE__.'"; Function = "'.$function['function'].'"; Line = '.$function['line'].';';
	if(is_array($text)){ $text = 'Array : '.json_encode($text); }
	$text = $cur_Date.' => Log = "'.$text.'"; '.PHP_EOL;
	fwrite($file, $text);
}	

function display($object){echo '<pre>'; print_r($object); echo '</pre>';}

//display(get_loaded_extensions());
//die();
/**/
$username = '919638696380';
$nickname = 'Mr. Smith';
$password = '/S8qCMLss9SaVlBpzEqHwCxCCBo=';
$login = 0;
$debug = false;
$url = false; //'http://leclient.ciphersoul.com/index.php/api/index';
$port = 5353;
/*/
$username = '917041887730';
$nickname = 'HelpLine';
$password = 'as3y8boi2k6ctaSufIX82BYFHW0=';
$login = 0;
$debug = false;
$port = 5352;
/**/
$whatsapp_instance = new WhatsappInstance($username,$password,$nickname,$url,$port,$debug);

if(! $whatsapp_instance->login()){
	
	//setLogin($phoneid,0);
	$response['statue'] = 607;
	$response['message'] = 'Login Faild';
	die(json_encode($response));		
}

$whatsapp_instance->run();	
$response['statue'] = 200;
$response['message'] = 'ok';
die(json_encode($response));	


