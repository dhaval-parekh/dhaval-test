<?php 
/**
 *	Class Name : FileProcess
 *	Use 		 : To Mage File Uploading
 *	Counstruct : 	@param 1 = Upload Path
 *				@param 2 = Return Path
 *				@param 3 = Extenion [Array]
 *				@param 4 = File Type [Array]
 *				@param 5 = Size max Size of file
 *
 */
	class File{
		private $_uploadPath;
		private $_extention = array();
		private $_fileType = array();
		private $_size ;
		
		/*public function FileProcess(){
			$this->_uploadPath=FALSE;
			$this->_extention=FALSE;
			$this->_fileType=FALSE;
			$this->_size=FALSE;	
		}*/ 
		// Coounstructor
		public function __construct($path = FALSE,$exten = FALSE,$type = FALSE ,$size = FALSE){
			if($path == ''){$path = FALSE;}
			if($exten == ''){$exten = FALSE;}
			if($type == ''){$type = FALSE;}
			if($size == ''){$size = FALSE;}
			
			$this->_uploadPath=$path;
			$this->_extention=$exten;
			$this->_fileType=$type;
			$this->_size=$size;	
		}
		public function Reset($path = FALSE,$exten = FALSE,$type = FALSE ,$size = FALSE){
			self::__construct($path,$exten,$type,$size);
		}
		
		// Display File Detail Args: fileName
		public function FileDetail($objName){
			if($_FILES[$objName]['error']>0){
				echo "Error : ".$_FILES[$objName]['error']."<br>";
				return false;
			}else{
				$aryTemp =  explode('.',$_FILES[$objName]['name']);
				$fileExtension = end($aryTemp);
				
				/*echo "upload : ".$_FILES[$objName]['name']."<br>";
				echo "Type : ".$_FILES[$objName]['type']."<br>";
				echo "Size : ".$_FILES[$objName]['size']."<br>";
				echo "Extension : .".$fileExtension."<br>";
				echo "Stored in : ".$_FILES[$objName]['tmp_name']."<br>";
				*/
				$file = array(
						'name' => $_FILES[$objName]['name'],
						'type' => $_FILES[$objName]['type'],
						'tmp_name' => $_FILES[$objName]['tmp_name'],
						'error' => $_FILES[$objName]['error'],
						'size' => $_FILES[$objName]['size'],
						'extension' => $fileExtension,
					);
				return true;
			}
		}
		// ValidateFile Args: fileName return:Bool
		public function ValidateFile($objName){
			$aryTemp =  explode('.',$_FILES[$objName]['name']);
			$fileExtension = strtolower(end($aryTemp));
			$fileType= $_FILES[$objName]['type'];
			if ( 
				$_FILES[$objName]['size'] < $this->_size 
				&& ((! $this->_extention) || in_array($fileExtension,$this->_extention) )
				&& ((! $this->_fileType) || in_array($fileType,$this->_fileType))
				//&& (! file_exists($this->_uploadPath.$_FILES[$objName]['name']))
			){
				return true;
			}else{
				return false;	
			}
		}
		
		// Upload File return:file Url on success
		public function UploadFile($objName,$fileName = false){
			if($fileName){
				$name_Extension =  explode('.',$fileName);
				if(count($name_Extension) == 1){
					// if Given name has no extension then appen extension 
					$aryTemp =  explode('.',$_FILES[$objName]['name']);
					if(count($aryTemp) > 1){
						$fileExtension = end($aryTemp);
						$fileName = $fileName.'.'.$fileExtension;	
					}
				}
			}else{
				$fileName = $_FILES[$objName]['name'];
			}
			//if($this->ValidateFile($objName)){
				move_uploaded_file($_FILES[$objName]['tmp_name'],$this->_uploadPath.$fileName);
				$fileLoction = $this->_uploadPath.$fileName;
				return $fileLoction;
			//}	
			return false;
		}
	}


