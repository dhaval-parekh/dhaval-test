<?php
function validateParam($requvired,&$args){
	$flag = false;
	foreach($requvired as $key=>$value){
		if(! array_key_exists($value[0],$args)){
			return false;
		}else{
			$args[$value[0]] = urldecode($args[$value[0]]);
			if(! _isParamValid($args[$value[0]],$value[1])){

				return false;	
			}
		}
	}
	return true;
}

function ResourceToArray($resource){
	if(gettype($resource)=="resource" && $resource){
		$array = array();
		while($row = mysql_fetch_assoc($resource)){
			$array[] = $row;
		}
		return $array;
	}else{
		return false;	
	}
}
function _isParamValid($value,$type){
	if($value){
		//$value = $param['value'];
		switch($type){
			case 'text':
			case 'password':

				break;
			case 'email':
					if(!filter_var($value, FILTER_VALIDATE_EMAIL) ):
						return false;
					endif;
				break;
			case 'tel':
					if((!is_numeric($value)) ):
						return false;
					elseif(! preg_match("/^[0-9]{10,15}$/", $value)):
						return false;
					endif;
				break;
			case 'number':
					if((!is_numeric($value)) ):
						return false;
					endif;
					break;
			case 'date':
					$d = date_parse_from_format("m-d-Y", $value);
					if(!checkdate($d['month'],$d['day'],$d['year'])):
						return false;
					endif;
				break;
			case 'checkbox':
					if(is_array($value) && count($value)<=0):
						return false;
					endif;
				break;
			case 'latitude':
						if((! is_numeric($value))):
							return false;	
						elseif( $value < -90 || $value > 90):
							return false;
						endif;
					break;
			case 'longitude':
						if((! is_numeric($value))):
							return false;	
						elseif( $value < -180 || $value > 180):
							return false;
						endif;
					break;
			case 'file':
					if($param['value']['error']){
						return false;	
					}
				break;
		}		
	}
	return true;
}


/*	Not Working	*/
function onSyncResult($result){
	echo '<br>onSyncResult \n <br>';
	display($result);
	system_log(__FUNCTION__);
}

function onGetRequestLastSeen( $mynumber, $from, $id, $seconds){
	echo '<br>onGetRequestLastSeen <br>';
	display($mynumber.' => '.$from);
	system_log(__FUNCTION__.' : '.$mynumber.' => '.$from);
}

function onPresenceAvailable($mynumber, $from){
	echo '<br>onPresenceAvailable  <br>';
	display($mynumber.' => '.$from);
	system_log(__FUNCTION__.' : '.$mynumber.' => '.$from);
}

function onPresenceUnavailable($mynumber, $from, $last){
	echo '<br>onPresenceUnavailable  <br>';
	display($mynumber.' => '.$from);
	system_log(__FUNCTION__.' : '.$mynumber.' => '.$from);
}
function onMessage($mynumber, $from, $id, $type, $time, $name, $body){
	echo '<br>onMessage  <br>';
	display($mynumber.' => '.$from.' => '.$name.' message => '.$body);
	system_log(__FUNCTION__.' : '.$mynumber.' => '.$from.' => '.$name.' message => '.$body);
	
	if($body == "1"){ 
		system_log(__FUNCTION__.'sleep start');
		sleep(10);
		die('exit command'); 
		system_log(__FUNCTION__.'sleep stop');
	}
	
}

function onGetImage($mynumber, $from, $id, $type, $time, $name, $size, $url, $file, $mimeType, $fileHash, $width, $height, $preview, $caption){
	echo '<br>onGetImage  <br>';
	display($mynumber.' => '.$from.' => '.$url);
	system_log(__FUNCTION__.' : '.$mynumber.' => '.$from.' => '.$url);
}

function onGetVideo($mynumber, $from, $id, $type, $time, $name, $url, $file, $size, $mimeType, $fileHash, $duration, $vcodec, $acodec, $preview, $caption){
	echo '<br>onGetVideo  <br>';
	display($mynumber.' => '.$from.' => '.$url);
	system_log(__FUNCTION__.' : '.$mynumber.' => '.$from.' => '.$url);
}

function onGetAudio($mynumber, $from, $id, $type, $time, $name, $size, $url, $file, $mimeType, $fileHash, $duration, $acodec, $fromJID_ifGroup = null){
	echo '<br>onGetAudio \n <br>';
	display($mynumber.' => '.$from.' => '.$url);
	system_log(__FUNCTION__.' : '.$mynumber.' => '.$from.' => '.$url);
}
/**/