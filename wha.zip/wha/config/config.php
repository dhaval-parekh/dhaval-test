<?php

// Site Setting
define('SITE_NAME', 'Nothing');
define('SITE_PHONE', '+12341234');

// Global Setting
define('BASE_PATH', dirname(dirname(__FILE__)));
define('BASE_URL', 'http://localhost/work/html/');
define('HOST', gethostbyname('localhost'));
//define('DB_NAME', 'whatsapp');
//define('DB_USER', 'root');
//define('DB_PASSWORD', '');
//define('DB_HOST', '127.0.0.1');


date_default_timezone_set('Asia/Kolkata');

define('INDEX', 'index.php');
define('DS', DIRECTORY_SEPARATOR);
define('APP_URL', BASE_URL.'app/');
define('API_URL', BASE_URL.INDEX.'/'.'api/');
define('ADMIN_URL', BASE_URL.INDEX.'/'.'admin/');
// session File Setting
ini_set('session.save_path',BASE_PATH.DS.'tmp'.DS.'session');
ini_set('max_execution_time', 0); //0=NOLIMIT
error_reporting(-1 & ~E_DEPRECATED);
error_reporting(-1);
session_start();

define('SITE_EMAIL','test@gmail.com');
define('SITE_EMAIL_PASS','test');


define('DEBUG_MODE', false);

/** MySQL settings - You can get this info from your web host **/

define('DB_SCRIPT_PATH', BASE_PATH.DS.'db'.DS.'database.sql');
define('DB_NAME', 'project.db');
define('DB_PATH', BASE_PATH.DS.'db'.DS);
define('DATABASE', DB_PATH.DB_NAME);


/*****	Dir Settings	*****/
define('DIR_CONFIG',BASE_PATH.DS.'config');

define('DIR_APP',BASE_PATH.DS.'app');
define('DIR_SYS',BASE_PATH.DS.'sys');
define('DIR_CONTROLLER',DIR_APP.DS.'controllers');
define('DIR_MODAL',DIR_APP.DS.'modals');
define('DIR_VIEW',DIR_APP.DS.'views');
define('DIR_LIBRARY',BASE_PATH.DS.'lib');

define('DIR_WHATSAPP',BASE_PATH.DS.'tmp'.DS.'whatsapp'.DS);

/** Upload Directory */
define('UPLOAD_DIR','uploads');

/*****	App Settings	*****/
//	--Not Used Yet
define('DEFAULT_CONTROLLER','index');
define('DEFAULT_ACTION','index');


// Load Class	//


//require_once(DIR_LIBRARY.'/classes/class.database-access.php');
require_once(DIR_LIBRARY.'/classes/class.database-access-sqllite.php');
require_once(DIR_LIBRARY.'/classes/class.url.php');
require_once(DIR_LIBRARY.'/classes/class.input.php');
require_once(DIR_LIBRARY.'/classes/class.form.php');
/*
require_once(DIR_LIBRARY.'/classes/whatsapp/whatsprot.class.php');
require_once(DIR_LIBRARY.'/classes/whatsapp/events/MyEvents.php');
require_once(DIR_LIBRARY.'/classes/class.whatsappinstance.php');
*/


// Load Main MVC Layers
require_once(DIR_SYS.'/core/controller.php');
require_once(DIR_SYS.'/core/modal.php');

//	Helpers
require_once(BASE_PATH.'/lib/helpers/helper.debug.php');
require_once(BASE_PATH.'/lib/helpers/helper.app.php');
require_once(BASE_PATH.'/lib/helpers/helper.url.php');


/**	Global Variables	**/
$Url = new Url(BASE_URL.INDEX);
$ApiUrl = new Url(API_URL);
