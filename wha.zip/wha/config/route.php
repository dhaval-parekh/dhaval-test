<?php
/*
 * Author: Dhaval Parekh 
 * Author Url: about.me/dmparekh
 * Company : 
 * Company Url : 
 * Description: route file
 *
 *
 *
 *
 *
 */
/*
 * NOTE: in Route the position of the route line will affect to actual Execution
 */

// /// Routes /////
$admin_route = array();
$route = array();
$route[''] = 'index/login';
$route['login'] = 'index/login';
$route['about'] = 'index/about';

if (isset($_SESSION['user'])) :

	$route[''] = 'index/index';
	$route['register'] = 'index/whaRegister';

else:

endif;


