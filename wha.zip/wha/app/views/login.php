<?php
	$base_url = rtrim(getBaseUrl(),'/').'/';
?>
<div class="container margin-top-lg">
	<div id="wrapper" class="col-sm-4 " style="margin:0 auto; float:none;">
		<div class="animate form login" id="login">
			<section class="login_content ">
				<?php echo $this->Form->Open($base_url.'login'); ?>
					<h3 id="logintitle">Login </h3>
					<p class="text-danger" id="loginmessage"><?php echo isset($message)?$message:false;?></p>
					<?php
						echo $this->Form->Input('email','email',false,'','',array('placeholder'=>'user@gmail.com'));
						echo $this->Form->Input('password','password',false,'','',array('placeholder'=>'Password'));
						echo $this->Form->Button('submit','submit','Login','btn-danger pull-right');
					?>
				<?php echo $this->Form->Close();?>
				<!-- form --> 
			</section>
			<!-- content --> 
		</div>
		
		<!-- content --> 
	</div>
</div>
