<?php
	$base_url = rtrim(getBaseUrl(),'/').'/';
?>
<div class="container margin-top-lg">
	<div id="wrapper" class="col-sm-4 " style="margin:0 auto; float:none;">
		<div class="animate form login" id="login">
			<section class="login_content ">
				<?php echo $this->Form->Open(); ?>
					<h3 id="logintitle">Regirster No.</h3>
					<p class="text-danger" id="loginmessage"><?php echo isset($message)?$message:false;?></p>
					<?php
						echo $this->Form->Input('phone','phone',false,'','',array('placeholder'=>'phone no. (with country code)'));
						echo $this->Form->Input('text','code',false,'','',array('placeholder'=>'6 digit code','disabled'=>'true'));
					?>
					<div class="form-group"	>
						<label><input type="checkbox" id="cbxSms" name="cbxSms">&nbsp; Already have code</label>
						<?php echo $this->Form->Button('submit','submit','Send Request','btn-danger pull-right'); ?>
					</div>
				<?php echo $this->Form->Close();?>
				<!-- form --> 
			</section>
			<!-- content --> 
		</div>
		
		<!-- content --> 
	</div>
</div>
<script type="text/javascript">
	var step = 1;
	document.getElementById('cbxSms').addEventListener('click',function(e){
		if(! this.checked){
			// request for new verification code 
			//step = 1;
			changeStep(1);
		}else{
			// Already have verification code	
			//step = 2;
			changeStep(2);
		}
	});
	document.getElementById('submit').addEventListener('click',function(e){
		if(step == 1){
			var api = 'registernumber';
			var data = new Object();
			data.phone = document.getElementById('phone').value;
			callApi(api,data,function(payload){
				if(payload.status != 200){ document.getElementById('loginmessage').innerHTML(payload.message); return false; }
				changeStep(2);
			})
		}else if(step == 2){
			
		}
		e.preventDefault();
		return false;
	});
	
	function changeStep(next_Step){
		if(next_Step == 1){
			jQuery('#code').attr('disabled',true);
			document.getElementById('cbxSms').checked = false;
		}else if(next_Step == 2){
			jQuery('#code').attr('disabled',false);
			document.getElementById('cbxSms').checked = true;
		}
	}
	
	function callApi(api,data,callback,method){
		if(typeof(method) == 'undefined' || method != 'GET' || method != 'POST'){
			method = 'POST';
		}
		jQuery.ajax({
			url: api_url+api,
			type:method,
			data:data,
			cache:false,
			success: function(data,status,xhr){
				if(typeof(callback) == 'function'){
					callback(data);
				}
			},
			error: function(xhr,status,error){
				console.log(error);
			}
		});
		
	}
</script>