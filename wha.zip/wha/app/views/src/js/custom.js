// JavaScript Document

//	Site Function 
var site  = {} || site;
site = {
}

// Home Page

