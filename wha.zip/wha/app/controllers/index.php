<?php 
class Index extends Controller{
	
	public function __construct(){
		parent::__construct();
		// Load Modals 
		$this->Url->setBaseurl(getBaseurl());
		
		$Header = $this->load_view('template/header');
		$Footer = $this->load_view('template/footer');
		$this->Template->setTemplate($Header,$Footer);
		
		
		//$this->Modal = $this->load_modal('indexmodal');
		
		
	}
	// Home Page
	public function index(){
		$data = array();
		$this->Template->setContent($this->load_view('home',$data));
		$this->Template->render();
	}
	
	public function login(){
		$data = array();
		if(isset($_SESSION['user'])){
			$this->Url->redirect(getBaseurl());
		}
		if($this->Input->isPostback){
			$post = $this->Input->Post();
			if(isset($post['email'],$post['password']) && $post['email'] == SITE_EMAIL && $post['password'] == SITE_EMAIL_PASS){
				$user = array();
				$user['email'] = $post['email'];
				$_SESSION['user'] = $user;
				$this->Url->redirect(getBaseurl());
			}else{
				$data['message'] = 'Username/Password are incorrect';
			}
		}
		$this->Template->setContent($this->load_view('login',$data));
		$this->Template->render();
	}
	
	public function whaRegister(){
		$data = array();
		$this->Template->setContent($this->load_view('wharegister',$data));
		$this->Template->render();
	}
	
	public function about(){
		$this->Template->setContent($this->load_view('about'));
		$this->Template->render();
	}
	
	public function page_404(){
		header('HTTP/1.1 404 Page Not Found');
		$this->Template->setContent('<h1 class="margin-top-lg text-theme text-center">404</h1>');
		$this->Template->render();
	}
}