<?php
class Whatsapp extends Controller{
	private $phone;
	private $instance;
	
	private $whatsapp;
	private $event;
	
	public function __construct(){
		parent::__construct();
		$this->PhoneModal = $this->load_modal('phonemodal');
		$this->port = 5351; 
	}	
	
	// Private Function 
	public function index(){
		return array('key'=>'value');
	}
	
	// Number Registration.
	public function api_sendRegistrationRequest(){
		$input = $this->Input->getInputValue();
		$debug = false;
		$phone = $input['phone'];
		$available_type = array('sms','voice');
		$type = isset($input['type'])&&in_array($input['type'],$available_type)?$input['type']:'sms';
		
		require_once(DIR_LIBRARY.'/classes/whatsapp/Registration.php');
		try{
			$registration = new Registration($phone,$debug);
			display($registration->codeRequest($type));
		}catch(Exception $e){
			return array('error'=>610);
		}
	}
	
	public function api_verifyRegistrationRequest(){
			
	}
	
	// Public function 
	public function add_update_phone($data){
		$response = array();
		$phone = $this->PhoneModal->getPhone($data['phone']);
		//$data['token'] = md5($data['phone'].time().$data['password']);
		$data['token'] = md5($data['phone'].$data['password']);
		$data['login'] = 0;
		$data['command'] = false;
		if($phone){
			// Update	
			$this->PhoneModal->add_update_phone($data,$phone['phone']);
		}else{
			// Insert
			$this->PhoneModal->add_update_phone($data);
		}
		$response['token'] = $data['token'];
		return $data['token'];
	}
	
	
	// API Handller
	public function api_addPhone(){
		$input = $this->Input->getInputValue();
		$phone = $this->PhoneModal->getPhone($input['phone']);

		$token = $this->add_update_phone($input);
		$phone = $this->PhoneModal->getPhoneByToken($token);
		unset($phone['login'],$phone['command']);
		return $phone;
	}

	// Send Ping 
	public function api_ping(){
		$input = $this->Input->getInputValue();
		$phone = $this->PhoneModal->getPhoneByToken($input['token']);
		if(!$phone){ return array('error'=>604); }
		if( $phone['login'] != 1){ return array('error'=>608);  }
		$command = 'ping';
		$request = array( 'command'=>$command );
		$port = $this->port;
		return $this->sendRequest($port,$request,$phone['phone']);
	}
	
	// Send Poll 
	public function api_poll(){
		$input = $this->Input->getInputValue();
		$phone = $this->PhoneModal->getPhoneByToken($input['token']);
		if(!$phone){ return array('error'=>604); }
		if( $phone['login'] != 1){ return array('error'=>608);  }
		$command = 'poll';
		$request = array( 'command'=>$command );
		$port = $this->port;
		return $this->sendRequest($port,$request,$phone['phone']);
	}
	
	// Login 
	public function api_login(){
		$input = $this->Input->getInputValue();
		$phone = $this->PhoneModal->getPhoneByToken($input['token']);
		if(!$phone){ return array('error'=>604); }
		if( $phone['login'] == 1){ return array('error'=>606);  }
		
		$debug = DEBUG_MODE;
		$phoneid = $phone['phoneid'];
		$port = 5351;
		/*
		set_time_limit(0);
		require_once(DIR_LIBRARY.'/classes/whatsapp/whatsprot.class.php');
		require_once(DIR_LIBRARY.'/classes/whatsapp/events/MyEvents.php');
		require_once(DIR_LIBRARY.'/classes/class.whatsappinstance.php');
		
		$whatsapp_instance = new WhatsappInstance($phone['phone'],$phone['password'],$phone['name'],$phone['url'],$port,$phone['token'],$debug);
		
		if(! $whatsapp_instance->login()){
			$this->PhoneModal->setLogin(0,$phoneid);
			return array('error'=>607);
		}
		$this->PhoneModal->setLogin(1,$phoneid);
		$whatsapp_instance->run();
		$this->PhoneModal->setLogin(0,$phoneid);*/
		return array('error'=>420);
		
	}
	// Logout 
	public function api_logout(){
		$input = $this->Input->getInputValue();
		$phone = $this->PhoneModal->getPhoneByToken($input['token']);
		if(!$phone){ return array('error'=>604); }
		if( $phone['login'] != 1){ return array('error'=>608);  }
		$this->PhoneModal->setLogin($phone['phoneid'],0);
		$command = 'logout';
		$request = array( 'command'=>$command );
		$port = $this->port;
		return $this->sendRequest($port,$request,$phone['phone']);
	}
	
	public function api_die(){
		$input = $this->Input->getInputValue();
		$phone = $this->PhoneModal->getPhoneByToken($input['token']);
		if(!$phone){ return array('error'=>604); }
		//if( $phone['login'] != 1){ return array('error'=>608);  }
		$this->PhoneModal->setLogin($phone['phoneid'],0);
		$command = 'die';
		$request = array( 'command'=>$command );
		$port = $this->port;
		return $this->sendRequest($port,$request,$phone['phone']);;
	}
	
	// Send Compossing
	public function api_sendMessageComposing(){
		$input = $this->Input->getInputValue();
		$phone = $this->PhoneModal->getPhoneByToken($input['token']);
		if(!$phone){ return array('error'=>604); }
		if( $phone['login'] != 1){ return array('error'=>608);  }
		$command = 'type';
		$request = array( 'command'=>$command , 'to'=>$input['to']);
		$port = $this->port;
		return $this->sendRequest($port,$request,$phone['phone']);
	}
	
	// Send Compossing Pause
	public function api_sendMessagePaused(){
		$input = $this->Input->getInputValue();
		$phone = $this->PhoneModal->getPhoneByToken($input['token']);
		if(!$phone){ return array('error'=>604); }
		if( $phone['login'] != 1){ return array('error'=>608);  }
		$command = 'pause';
		$request = array( 'command'=>$command , 'to'=>$input['to']);
		$port = $this->port;
		return $this->sendRequest($port,$request,$phone['phone']);
	}
	
	// Send Message
	public function api_sendmessage(){
		$input = $this->Input->getInputValue();
		$command = 'send';
		$phone = $this->PhoneModal->getPhoneByToken($input['token']);
		if(!$phone){ return array('error'=>604); }
		if( $phone['login'] != 1){ return array('error'=>608);  }
		$input['command'] = $command;
		unset($input['token']);
		//$this->PhoneModal->setCommand($phone['phoneid'],json_encode($input)); 
		
		$port = $this->port;
		$response = $this->sendRequest($port,$input,$phone['phone']);
		return $response;
		if(isset($response['status']) && $response['status'] == 200 ){
			return $response['payload']; 
		}
		return array('error'=>420);
		
	}
	
	private function sendRequest($port,$command = array(),$phone = false){
		if(! ( isset($port) && is_numeric($port) )){ return false; }
		if(! ( is_array($command) && count($command) >0 )){ return false; }
		$host = HOST;
		
		$command = json_encode($command);
		system_log(__FUNCTION__.' '.$command);
		$file = fopen(DIR_WHATSAPP.$phone,'w');
		fwrite($file,$command);
		fclose($file);
		//return true; 
		//return file_get_contents(DIR_WHATSAPP.$phone);
		
		// create socket
		$socket = socket_create(AF_INET, SOCK_STREAM, 0) or die(json_encode(array('status'=>610,'message'=>'Could not create socket'))); // die("Could not create socket\n");

		// connect to server
		$result = socket_connect($socket, $host, $port) or die(json_encode(array('status'=>610,'message'=>'Could not connect to server'))); //die("Could not connect to server\n");  

		// send string to server
		socket_write($socket, $command, strlen($command)) or die(json_encode(array('status'=>610,'message'=>'Could not send data to server'))); // die("Could not send data to server\n");

		// get server response
		$result = socket_read($socket, 2048) or die(json_encode(array('status'=>610,'message'=>'Could not read server response'))); //die("Could not read server response\n");
		$result = json_decode($result);

		return $result;
	}
	
	
	// Poll Message
	public function api_pollMessage(){
		
	
	}
	
	// Send Active Status
	public function api_sendActiveStatus(){
		
	}

	// Send Sync
	public function api_sendSync(){
		$input = $this->Input->getInputValue();
		$command = 'sync';
		$phone = $this->PhoneModal->getPhoneByToken($input['token']);
		if(!$phone){ return array('error'=>604); }
		if( $phone['login'] != 1){ return array('error'=>608);  }
		
		$contacts = $input['contacts'];
		$contacts = array_unique($contacts);
		$request = array( 'command'=>$command , 'contacts'=>$contacts);
		
		$port = $this->port;
		return $this->sendRequest($port,$request,$phone['phone']);;
	}
	
}
