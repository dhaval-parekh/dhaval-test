<?php
class VehicleModal extends Modal{
	
	public function __construct(){
		parent::__construct();
	}
	
}