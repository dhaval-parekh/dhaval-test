<?php
class PhoneModal extends Modal{

	public function __construct(){
		parent::__construct();
	}
	
	public function getPhone($phone){
		if(! (isset($phone) && is_numeric($phone) )){ return false; }
		$query = "SELECT * FROM phone_master WHERE phone = '".$phone."'; ";
		$detail = $this->Database->getRow($query);
		if($detail){
			return $detail;
		}
		return false;	
	}
	
	public function getPhoneByToken($token){
		if(! (isset($token)  )){ return false; }
		$query = "SELECT * FROM phone_master WHERE token = '".$token."'; ";
		$detail = $this->Database->getRow($query);
		if($detail){
			return $detail;
		}
		return false;			
	}
	
	public function add_update_phone($data,$phone = false){
		$flag = false;
		if($phone && is_numeric($phone) ){
			
			$query  = "UPDATE phone_master SET ";
			
			if(isset($data['name'])){
				$query .= $flag?' , ':'';
				$query .= " name = '".$data['name']."' ";
				$flag = true;
			}
			
			if(isset($data['password'])){
				$query .= $flag?' , ':'';
				$query .= " password = '".$data['password']."' ";
				$flag = true;
			}
			
			if(isset($data['token'])){
				$query .= $flag?' , ':'';
				$query .= " token = '".$data['token']."' ";
				$flag = true;
			}
			
			if(isset($data['login']) && is_numeric($data['login']) ){
				$query .= $flag?' , ':'';
				$query .= " login = '".$data['login']."' ";
				$flag = true;
			}
			
			if(isset($data['url'])){
				$query .= $flag?' , ':'';
				$query .= " url = '".$data['url']."' ";
				$flag = true;
			}
			
			/*if(isset($data['command'])){
				$query .= $flag?' , ':'';
				$query .= " command = '".$data['command']."' ";
				$flag = true;
			}*/
			
			$query .= "WHERE phone = '".$phone."'; ";
			
		}else{
			if(isset($data['phone'],$data['name'],$data['password'],$data['token'] ) && 
				is_numeric($data['phone'])  ){
				$data['login'] = isset($data['login'])&&is_numeric($data['login'])?$data['login']:0;
				$data['url'] = isset($data['url'])?"'".$data['url']."'":'NULL';
				
				$query = "INSERT INTO phone_master (phone,name,password,token,url) VALUES
						('".$data['phone']."','".$data['name']."','".$data['password']."','".$data['token']."',".$data['url']."); ";
				$flag = true;
			}
		}
		
		if($flag){
			if($this->Database->ExecuteNoneQuery($query) == 1){
				$flag = true;
			}else{
				$flag = false;	
			}
		}
		
		return $flag;
	}	
	
	
	public function setLogin($id,$login){
		if(! (isset($id) && is_numeric($id))){ return false; }
		if(! (isset($login) )){ return false; }
		
		$login = $login == 1?1:0;
		$query = "UPDATE phone_master SET login = ".$login." WHERE phoneid = ".$id." ";

		return $this->Database->ExecuteNoneQuery($query);
	}
	
	public function getLogin($id){
		if(! (isset($id) && is_numeric($id))){ return false; }
		$query = "SELECT login FROM phone_master WHERE phoneid = ".$id." ";
		return $this->Database->getFirstValue($query);
	}
	
	/*
	public function setCommand($id,$command){
		if(! (isset($id) && is_numeric($id))){ return false; }
		if(! (isset($command))){ return false; }
		
		$query = "UPDATE phone_master SET command = '".$command."' WHERE phoneid = ".$id." ";
		return $this->Database->ExecuteNoneQuery($query);
	}
	
	public function getCommand($id){
		if(! (isset($id) && is_numeric($id))){ return false; }
		$query = "SELECT command FROM phone_master WHERE phoneid = ".$id." ";
		$result = $this->Database->getFirstValue($query);
		return $result;
	}
	*/
}