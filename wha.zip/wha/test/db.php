<html>
<head>
	<title>whatapp Local database</title>
	<style>
		table{ width:100%; text-align:center; }
	</style>
</head>
<body>
<?php
function display($object){
	if(gettype($object)=="resource" && $object)
	{
		$No=mysql_num_fields($object)
		or
		die(mysql_error()."<br>");
		echo "<table class='table table-bordered' style='width:100%;text-align:center;'  cellpadding='5' border='1' cellspacing='0'>";
		echo "<tr>";
		for($i=0;$i<$No;$i++)

		{
			$FieldName=mysql_field_name($object,$i)
			or
			die(mysql_error()."<br>");
			echo "<th><label>".$FieldName."</label></th>";
		}
		echo "</tr>";
		while($row=mysql_fetch_row($object))
		{
			echo "<tr>";
			for($i=0;$i<$No;$i++)
			{
				 echo "<td>".$row[$i]."</td>";
			}
			echo "</tr>";
		}
		echo "</table>";
	}else{
		echo '<pre style="max-height:256px;overflow:auto;">';
			if(is_object($object) || is_array($object)){
				print_r($object); 
			}else{
				echo $object; 
			}
		echo '</pre>';	
	}
	return true;
}


	require('../lib/classes/class.database-access.php');
	/** The name of the database for WordPress */
	define('DB_NAME', 'whatsapp');

	/** MySQL database username */
	define('DB_USER', 'dmp');

	/** MySQL database password */
	define('DB_PASSWORD', 'Apollo@007');

	/** MySQL hostname */
	define('DB_HOST', 'localhost');

	$con = new DatabaseAccess(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);
	$con->Open();

	$showtable = "SHOW TABLES ";	
	//display($con->ExecuteQuery($showtable));
	
	$query = "select * from phone_master";
	display($con->ExecuteQuery($query));

?>

</body>

</html>

