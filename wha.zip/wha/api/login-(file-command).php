<?php

ini_set('max_execution_time', 0); //0=NOLIMIT
/**/
define('BASE_PATH', dirname(dirname(__FILE__)));
define('BASE_URL', 'http://localhost/whatsapp/');
define('HOST', gethostbyname('localhost'));
define('DB_NAME', 'whatsapp');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_HOST', 'localhost');
/*/
define('BASE_PATH', dirname(dirname(__FILE__)));
define('BASE_URL', 'http://dmp007.cloudapp.net/');
define('HOST', gethostbyname('dmp007.cloudapp.net'));
define('DB_NAME', 'whatsapp');
define('DB_USER', 'dmp');
define('DB_PASSWORD', 'Apollo@007');
define('DB_HOST', 'localhost');
/**/

define('INDEX', 'index.php');
define('DS', DIRECTORY_SEPARATOR);
define('APP_URL', BASE_URL.'app/');
define('API_URL', BASE_URL.INDEX.'/'.'api/');

define('DIR_WHATSAPP',BASE_PATH.DS.'tmp'.DS.'whatsapp'.DS);
//error_reporting(0);
error_reporting(-1 & ~E_DEPRECATED);
error_reporting(-1);

require_once('../lib/classes/whatsapp/whatsprot.class.php');
require_once('../lib/classes/whatsapp/Login.php');
require_once('../lib/classes/whatsapp/events/MyEvents.php');

require_once('class.database-access.php');
require_once('../lib/classes/class.whatsappinstance.php');

$con = new DatabaseAccess(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);

$con->Open();

function system_log($text){
	$file_name = 'server.txt';
	$file = fopen($file_name, "a");
	$cur_Date = date('Y-m-d H:i:s');
	if(is_array($text)){ $text = 'Array : '.json_encode($text); }
	$text = $cur_Date.' => Log = "'.$text.'"; '.PHP_EOL;
	fwrite($file, $text);
}	
function display($object){echo '<pre>'; print_r($object); echo '</pre>';}

//system_log(get_loaded_extensions());
//display(get_loaded_extensions());


// Database function 
// get Phone
function getPhone($phone){
	global $con;
	if(! (isset($phone) && is_numeric($phone) )){ return false; }
	$query = "SELECT * FROM phone_master WHERE phone = '".$phone."'; ";
	$detail = $con->getRow($query);
	if($detail){
		return $detail;
	}
	return false;	
}

// get Phone By token
function getPhoneByToken($token){
	global $con;
	if(! (isset($token)  )){ return false; }
	$query = "SELECT * FROM phone_master WHERE token = '".$token."'; ";
	$detail = $con->getRow($query);
	if($detail){
		return $detail;
	}
	return false;			
}

//	set Login 
function setLogin($id,$login){
	global $con;
	if(! (isset($id) && is_numeric($id))){ return false; }
	if(! (isset($login) )){ return false; }
	
	$login = $login == 1?1:0;
	$query = "UPDATE phone_master SET login = ".$login." WHERE phoneid = ".$id." ";

	return $con->ExecuteNoneQuery($query);
}

// Login start here
header('Content-Type: application/json');

$input = $_REQUEST;
$response = array();

// check for bad request 
if(!( isset($input['token'])  )){
	$response['statue'] = 400;
	$response['message'] = 'Bad Request';
	die(json_encode($response));	
}

$token = $input['token'];
$phone = getPhoneByToken($token);

if(!$phone){
	$response['statue'] = 609;
	$response['message'] = 'Device Not Found';
	die(json_encode($response));	
}
if($phone['login'] == 1){
	$response['statue'] = 606;
	$response['message'] = 'Phone Number Already Loged in';
	die(json_encode($response));	
}


//die(json_encode($phone));
///// Create New Instance for new mobile
$debug = false;
$phoneid = $phone['phoneid'];

$port = 5351;
$whatsapp_instance = new WhatsappInstance($phone['phone'],$phone['password'],$phone['name'],$phone['url'],$port,$phone['token'],$debug);

$file  = fopen(DIR_WHATSAPP.$phone['phone'],'w');
//fwrite($file, 'start');
//fclose($file);

set_time_limit(0);
if(! $whatsapp_instance->login()){
	
	setLogin($phoneid,0);
	$response['statue'] = 607;
	$response['message'] = 'Login Faild';
	die(json_encode($response));		
}

setLogin($phoneid,1);
$whatsapp_instance->run();	
setLogin($phoneid,0);
$response['statue'] = 200;
$response['message'] = 'ok';
die(json_encode($response));	


/*
display(get_declared_classes());
$w = new WhatsProt($phone['phone'],$phone['name'],$debug);
$event = new MyEvents($w);
$w->connect();
try{
	$w->loginWithPassword($phone['password']);
}catch(Exception $e){
	display($e);
	exit();
}
echo "\nConnected to WA \n";

*/

/*/
$username = '919638696380';
$nickname = 'Mr. Smith';
$password = 'QckpAhnEw88S9eVEzScyKhOmQro=';
$login = 0;
$debug = false;
$port = 5351;
//
$username = '917041887730';
$nickname = 'HelpLine';
$password = 'as3y8boi2k6ctaSufIX82BYFHW0=';
$login = 0;
$debug = false;
$port = 5352;
/**/
/*
function onSyncResult($result){
	echo '<br>onSyncResult \n <br>';
	display($result);
}

function onGetRequestLastSeen( $mynumber, $from, $id, $seconds){
	system_log(__FUNCTION__.' : '.$mynumber.' => '.$from);
}

function onPresenceAvailable($mynumber, $from){
	system_log(__FUNCTION__.' : '.$mynumber.' => '.$from);
}

function onPresenceUnavailable($mynumber, $from, $last){
	system_log(__FUNCTION__.' : '.$mynumber.' => '.$from);
}
function onMessage($mynumber, $from, $id, $type, $time, $name, $body){
	echo '<br>onMessage  <br>'.$body;
	system_log(__FUNCTION__.' : '.$mynumber.' => '.$from.' => '.$name.' message => '.$body);
	if($body == "1"){ sleep(1); die('exit command'); }
}

function onGetImage($mynumber, $from, $id, $type, $time, $name, $size, $url, $file, $mimeType, $fileHash, $width, $height, $preview, $caption){
	system_log(__FUNCTION__.' : '.$mynumber.' => '.$from.' => '.$url);
}

function onGetVideo($mynumber, $from, $id, $type, $time, $name, $url, $file, $size, $mimeType, $fileHash, $duration, $vcodec, $acodec, $preview, $caption){
	system_log(__FUNCTION__.' : '.$mynumber.' => '.$from.' => '.$url);
}

function onGetAudio($mynumber, $from, $id, $type, $time, $name, $size, $url, $file, $mimeType, $fileHash, $duration, $acodec, $fromJID_ifGroup = null){
	system_log(__FUNCTION__.' : '.$mynumber.' => '.$from.' => '.$url);
}
/**/
