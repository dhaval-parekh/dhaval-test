<?php

function system_log($text){
	$file_name = 'server.txt';
	$file = fopen($file_name, "a");
	$cur_Date = date('Y-m-d H:i:s');
	if(is_array($text)){ $text = 'Array : '.json_encode($text); }
	$text = $cur_Date.' => Log = "'.$text.'"; '.PHP_EOL;
	fwrite($file, $text);
}	
function display($object){echo '<pre>'; print_r($object); echo '</pre>';}

//system_log(get_loaded_extensions());
//display(get_loaded_extensions());

// Login start here
header('Content-Type: application/json');

$input = $_REQUEST;
$response = array();

// check for bad request 
if(!( isset($input['token'])  )){
	$response['statue'] = 400;
	$response['message'] = 'Bad Request';
	die(json_encode($response));	
}

$token = $input['token'];
set_time_limit(0);
//display(PHP_SAPI);
$command = 'php login-request.php '.$token; 
echo shell_exec($command);

//$response['statue'] = 200;
//$response['message'] = 'ok';
//die(json_encode($response));

