<?php
ini_set('max_execution_time', 0); //0=NOLIMIT
/**/
define('BASE_PATH', dirname(dirname(__FILE__)));
define('BASE_URL', 'http://localhost/whatsapp/');
define('HOST', '127.0.0.1');
define('DB_NAME', 'whatsapp');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_HOST', '127.0.0.1');
/*/
define('BASE_PATH', dirname(dirname(__FILE__)));
define('BASE_URL', 'http://dmp007.cloudapp.net/');
define('HOST',  '127.0.0.4');//gethostbyname('dmp007.cloudapp.net'));
define('DB_NAME', 'whatsapp');
define('DB_USER', 'dmp');
define('DB_PASSWORD', 'Apollo@007');
define('DB_HOST', 'localhost');
/**/

define('INDEX', 'index.php');
define('DS', DIRECTORY_SEPARATOR);
define('APP_URL', BASE_URL.'app/');
define('API_URL', BASE_URL.INDEX.'/'.'api/');

date_default_timezone_set('America/Los_Angeles');
define('DIR_WHATSAPP',BASE_PATH.DS.'tmp'.DS.'whatsapp'.DS);
//error_reporting(0);
error_reporting(-1 & ~E_DEPRECATED);
//error_reporting(-1);

require_once('class.database-access.php');


$con = new DatabaseAccess(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);
$con->Open();

function system_log($text){
	$file_name = 'cron.txt';
	$file = fopen($file_name, "a");
	$cur_Date = date('Y-m-d H:i:s');
	if(is_array($text)){ $text = 'Array : '.json_encode($text); }
	$text = $cur_Date.' => Log = "'.$text.'"; '.PHP_EOL;
	fwrite($file, $text);
}	
function display($object){echo '<pre>'; print_r($object); echo '</pre>';}


//**********************************************************************************************//
//******************************************** FUNC ********************************************//
//**********************************************************************************************//
// Database function 
function getPhone($phone){
	global $con;
	if(! (isset($phone) && is_numeric($phone) )){ return false; }
	$query = "SELECT * FROM phone_master WHERE phone = '".$phone."'; ";
	$detail = $con->getRow($query);
	if($detail){
		return $detail;
	}
	return false;	
}

function getPhoneByToken($token){
	global $con;
	if(! (isset($token)  )){ return false; }
	$query = "SELECT * FROM phone_master WHERE token = '".$token."'; ";
	$detail = $con->getRow($query);
	if($detail){
		return $detail;
	}
	return false;			
}

function setLogin($id,$login){
	global $con;
	if(! (isset($id) && is_numeric($id))){ return false; }
	if(! (isset($login) )){ return false; }
	$login = $login == 1?1:0;
	$query = "UPDATE phone_master SET login = ".$login." WHERE phoneid = ".$id." ";
	return $con->ExecuteNoneQuery($query);
}

header('Content-Type: application/json');

$input = $_REQUEST;
$response = array();

if(PHP_SAPI == 'cli'){
	/*$response['statue'] = 401;
	$response['message'] = 'Forbidan';
	die(json_encode($response));	*/
	$input = array(); //$argv;
	$input['token'] = $argv[1];
}

// check for bad request 
if(!( isset($input['token'])  )){
	$response['statue'] = 400;
	$response['message'] = 'Bad Request';
	die(json_encode($response));	
}

$token = $input['token'];
$phone = getPhoneByToken($token);

if(!$phone){
	$response['statue'] = 609;
	$response['message'] = 'Device Not Found';
	die(json_encode($response));	
}
if($phone['login'] == 0){
	$response['statue'] = 606;
	$response['message'] = 'Phone Number is not Logedin';
	die(json_encode($response));	
}


//die(json_encode($phone));
///// Create New Instance for new mobile
$debug = false;
$phoneid = $phone['phoneid'];
//**********************************************************************************************//
//******************************************** CODE ********************************************//
//**********************************************************************************************//

function sendRequest($url,$port){
	//echo $url.'	=>'.time().PHP_EOL;
	$host = HOST;
	
	$response = file_get_contents($url);
	system_log($response);
	$response_array = json_decode($response,true);
	if($response_array['status'] != 200){
		system_log('==========================================  CLOSE  ==========================================');
		die($response)	;
	}
	return $response;
	/*$socket = socket_create(AF_INET, SOCK_STREAM, 0) or die(json_encode(array('status'=>610,'message'=>'Could not create socket'))); // die("Could not create socket\n");
	// connect to server
	$result = socket_connect($socket, $host, $port) or die(json_encode(array('status'=>610,'message'=>'Could not connect to server'))); //die("Could not connect to server\n");  

	// send string to server
	socket_write($socket, $command, strlen($command)) or die(json_encode(array('status'=>610,'message'=>'Could not send data to server'))); // die("Could not send data to server\n");

	// get server response
	$result = socket_read($socket, 2048) or die(json_encode(array('status'=>610,'message'=>'Could not read server response'))); //die("Could not read server response\n");
	$result = json_decode($result);

	return $result;*/
}
$before_time = 1;

$request = http_build_query($input);
$ping_url = API_URL.'ping/?'.$request;
$poll_url = API_URL.'poll/?'.$request;
$port = 5152;
$count = 0; 

while($count < 100){
	$count++;
	
	$start_time = time();
	$end_time = $start_time+(60-$before_time);
	system_log('Ping ======> '.$count);
	$ping_response = sendRequest($ping_url);
	
	while(time() < $end_time){
		system_log('poll => '.$count);
		$response = sendRequest($poll_url);
		//sleep(1);
	}
}



