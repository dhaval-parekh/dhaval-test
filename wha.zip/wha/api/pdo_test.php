<?php

define('BASE_PATH', dirname(dirname(__FILE__)));
define('BASE_URL', 'http://localhost/whatsapp/');
define('HOST', gethostbyname('localhost'));
define('DB_NAME', 'whatsapp');
define('DB_USER', 'root');
define('DB_PASSWORD', '');
define('DB_HOST', '127.0.0.1');



require_once('class.database-access.php');

$con = new DatabaseAccess(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);
$con->Open();
$query = "SELECT * FROM phone_master;";
//$query = 'test';
//$query = "INSERT INTO phone_master (phoneid,phone,name,password,token,login,url) VALUES (DEFAULT,'913216549187','Mr. Name','pass','token',0,NULL);";
//$result = $con->ExecuteNoneQuery($query);
$result = $con->ExecuteQuery($query);
//$result = $con->getRow($query);
//$result = $con->getFirstValue($query);

print_r($result);
