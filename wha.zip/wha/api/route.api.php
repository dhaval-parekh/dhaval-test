<?php
$api_route = array();
$api_route['index'] = new ApiRequest(
							'whatsapp/index', 
							'GET',
							false, //'application/json',
							array(
								//'uid'=>array('type'=>'number','required'=>true)
							)
						);
						
$api_route['registernumber'] = new ApiRequest(
							'whatsapp/api_sendRegistrationRequest', 
							'POST',
							false, //'application/json',
							array(
								'phone'=>array('type'=>'tel','required'=>true),
								'type'=>array('type'=>'number','required'=>false),
							)
						);
						
$api_route['verifyregisternumber'] = new ApiRequest(
							'whatsapp/api_verifyRegistrationRequest', 
							'POST',
							false, //'application/json',
							array(
								'phone'=>array('type'=>'tel','required'=>true),
								'code'=>array('type'=>'number','required'=>true),
							)
						);

$api_route['addphone'] = new ApiRequest(
							'whatsapp/api_addPhone',
							'POST',
							false, //'application/json',
							array(
								'phone'=>array('type'=>'tel','required'=>true), // with country code
								'name'=>array('type'=>'text','required'=>true),
								'password'=>array('type'=>'text','required'=>true),
								'url'=>array('type'=>'text','required'=>false),
							)
						);
						
$api_route['ping'] = new ApiRequest(
							'whatsapp/api_ping',
							'GET',
							false, //'application/json',
							array(
								'token'=>array('type'=>'text','required'=>true), 
							)
						);

$api_route['poll'] = new ApiRequest(
							'whatsapp/api_poll',
							'GET',
							false, //'application/json',
							array(
								'token'=>array('type'=>'text','required'=>true), 
							)
						);
						
$api_route['login'] = new ApiRequest(
							'whatsapp/api_login',
							'GET',
							false, //'application/json',
							array(
								'token'=>array('type'=>'text','required'=>true), 
							)
						);

$api_route['logout'] = new ApiRequest(
							'whatsapp/api_logout',
							'GET',
							false, //'application/json',
							array(
								'token'=>array('type'=>'text','required'=>true), 
							)
						);
						
$api_route['die'] = new ApiRequest(
							'whatsapp/api_die',
							'GET',
							false, //'application/json',
							array(
								'token'=>array('type'=>'text','required'=>true),
							)
						);
						
$api_route['sendcomposing'] = new ApiRequest(
							'whatsapp/api_sendMessageComposing',
							'POST',
							false, //'application/json',
							array(
								'token'=>array('type'=>'text','required'=>true),
								//'time'=>array('type'=>'number','required'=>true),
								'to'=>array('type'=>'tel','required'=>true), // with country code
							)
						);
						
$api_route['messagepaused'] = new ApiRequest(
							'whatsapp/api_sendMessagePaused',
							'POST',
							false, //'application/json',
							array(
								'token'=>array('type'=>'text','required'=>true),
								//'time'=>array('type'=>'number','required'=>true),
								'to'=>array('type'=>'tel','required'=>true), // with country code
							)
						);

$api_route['sendmessage'] = new ApiRequest(
							'whatsapp/api_sendmessage',
							'POST',
							false, //'application/json',
							array(
								'token'=>array('type'=>'text','required'=>true),
								'to'=>array('type'=>'tel','required'=>true), // with country code
								'message'=>array('type'=>'text','required'=>true),
								'messagetype'=>array('type'=>'number','required'=>true),
							)
						);

//sendActiveStatus	
$api_route['sendactivestatus'] = new ApiRequest(
							'whatsapp/api_sendActiveStatus',
							'POST',
							false, //'application/json',
							array(
								'token'=>array('type'=>'text','required'=>true),
								'time'=>array('type'=>'number','required'=>true),
							)
						);	

$api_route['sync'] = new ApiRequest(
							'whatsapp/api_sendSync',
							'POST',
							false, //'application/json',
							array(
								'token'=>array('type'=>'text','required'=>true),
								'contacts'=>array('type'=>'text','required'=>true), // with country code
							)
						);
