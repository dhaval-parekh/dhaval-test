<?php
//mysql_connect();
//mysqli_connect();
//die();
ini_set('max_execution_time', 0); //0=NOLIMIT

define('BASE_PATH', dirname(dirname(__FILE__)));
define('BASE_URL', 'http://localhost/whatsapp/');
define('HOST', '127.0.0.1');
//define('DB_NAME', 'whatsapp');
//define('DB_USER', 'root');
//define('DB_PASSWORD', '');
//define('DB_HOST', '127.0.0.1');

define('DB_SCRIPT_PATH', BASE_PATH.DS.'db'.DS.'database.sql');
define('DB_NAME', 'project.db');
define('DB_PATH', BASE_PATH.DS.'db'.DS);
define('DATABASE', DB_PATH.DB_NAME);


define('INDEX', 'index.php');
define('DS', DIRECTORY_SEPARATOR);
define('APP_URL', BASE_URL.'app/');
define('API_URL', BASE_URL.INDEX.'/'.'api/');

define('DIR_WHATSAPP',BASE_PATH.DS.'tmp'.DS.'whatsapp'.DS);
date_default_timezone_set('Asia/Kolkata');
//error_reporting(0);
error_reporting(-1 & ~E_DEPRECATED);
//error_reporting(-1);

require_once('../lib/classes/whatsapp/whatsprot.class.php');
require_once('../lib/classes/whatsapp/Login.php');
require_once('../lib/classes/whatsapp/events/MyEvents.php');

//require_once('class.database-access.php');
require_once('class.database-access-sqllite.php');
require_once('../lib/classes/class.whatsappinstance.php');

//$con = new DatabaseAccess(DB_HOST,DB_USER,DB_PASSWORD,DB_NAME);
$con =  new sqlLite_DatabaseAccess(DATABASE,DB_SCRIPT_PATH);

$con->Open();

function system_log($text){
	$file_name = 'server.txt';
	$file = fopen($file_name, "a");
	$cur_Date = date('Y-m-d H:i:s');
	if(is_array($text)){ $text = 'Array : '.json_encode($text); }
	$text = $cur_Date.' => Log = "'.$text.'"; '.PHP_EOL;
	fwrite($file, $text);
}	
function display($object){echo '<pre>'; print_r($object); echo '</pre>';}

//system_log(get_loaded_extensions());
//display(get_loaded_extensions());


// Database function 
// get Phone
function getPhone($phone){
	global $con;
	if(! (isset($phone) && is_numeric($phone) )){ return false; }
	$query = "SELECT * FROM phone_master WHERE phone = '".$phone."'; ";
	$detail = $con->getRow($query);
	if($detail){
		return $detail;
	}
	return false;	
}

// get Phone By token
function getPhoneByToken($token){
	global $con;
	if(! (isset($token)  )){ return false; }
	$query = "SELECT * FROM phone_master WHERE token = '".$token."'; ";
	$detail = $con->getRow($query);
	if($detail){
		return $detail;
	}
	return false;			
}

//	set Login 
function setLogin($id,$login){
	global $con;
	if(! (isset($id) && is_numeric($id))){ return false; }
	if(! (isset($login) )){ return false; }
	
	$login = $login == 1?1:0;
	$query = "UPDATE phone_master SET login = ".$login." WHERE phoneid = ".$id." ";

	return $con->ExecuteNoneQuery($query);
}

// Login start here
header('Content-Type: application/json');
if(PHP_SAPI !== 'cli'){
	$response['statue'] = 401;
	$response['message'] = 'Forbidan';
	die(json_encode($response));	
}
$input = array(); //$argv;
$input['token'] = $argv[1];
//die(json_encode($input));
$response = array();

// check for bad request 
if(!( isset($input['token'])  )){
	$response['statue'] = 400;
	$response['message'] = 'Bad Request';
	die(json_encode($response));	
}

$token = $input['token'];
$phone = getPhoneByToken($token);

if(!$phone){
	$response['statue'] = 609;
	$response['message'] = 'Device Not Found';
	die(json_encode($response));	
}
if($phone['login'] == 1){
	$response['statue'] = 606;
	$response['message'] = 'Phone Number Already Loged in';
	die(json_encode($response));	
}


//die(json_encode($phone));
///// Create New Instance for new mobile
$debug = false;
$phoneid = $phone['phoneid'];
$port = 5351;
$whatsapp_instance = new WhatsappInstance($phone['phone'],$phone['password'],$phone['name'],$phone['url'],$port,$phone['token'],$debug);

$file  = fopen(DIR_WHATSAPP.$phone['phone'],'w');
//fwrite($file, 'start');
//fclose($file);

set_time_limit(0);
if(! $whatsapp_instance->login()){
	
	setLogin($phoneid,0);
	$response['statue'] = 607;
	$response['message'] = 'Login Faild';
	die(json_encode($response));		
}

//die('test');
setLogin($phoneid,1);
$whatsapp_instance->start();
$whatsapp_instance->startServices();
//$whatsapp_instance->poll();
//$whatsapp_instance->kill();	
setLogin($phoneid,0);
$response['statue'] = 200;
$response['message'] = 'ok';
die(json_encode($response));	

