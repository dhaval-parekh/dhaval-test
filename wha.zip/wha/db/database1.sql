CREATE TABLE IF NOT EXISTS phone_master
(
phoneid INTEGER NOT NULL AUTOINCREMENT PRIMARY KEY,
phone NUMERIC(20) NOT NULL ,
name VARCHAR(512) NOT NULL,
password VARCHAR(512) NOT NULL,
token VARCHAR(512),
login INTEGER default 0,
url varchar(2048)
);

INSERT INTO phone_master (phoneid,phone,name,password,token,login,url) VALUES (DEFAULT,'919638696380','Mr. Smith','/S8qCMLss9SaVlBpzEqHwCxCCBo=','e54fa16e0a24df09f10f8d816b172416',0,NULL);

