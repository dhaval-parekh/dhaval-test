<p class="text-danger" ng-bind="message[0]"></p>
<div  class="row " >
	<div class="padding-sm col-xs-12">
		<p class="text-theme text-bold text-center"><label>{{ 'OrderID' | translate }} : <span ng-bind="order.appointment_id"></span></label></p>
		<?php /*?><p class="text-thin">
			<label class="pull-left" ng-bind="order.date_text"></label>
			<label class="pull-right label {{ order.status_class }}" ng-bind="order.status_text"></label>
		</p><?php */?>
	</div>
	<div class="col-xs-6">
		<address>
		<strong>{{ 'YourOrderStartedOn' | translate }}</strong><br>
		<span ng-bind="order.start_date_string"></span><br>
		</address>
	</div>
	<div class="col-xs-6">
		<address>
		<strong>{{ 'YourOrderEndedOn' | translate }}</strong><br>
		<span ng-bind="order.complete_date_string"></span><br>
		</address>
	</div>
	<div class="clear"></div>
	<hr>
	<div class="" ng-hide="order.mas_id==0 || order.mas_id=='' ">
		<div class="col-sm-4">
			<a href="javascript:" class="thumbnail">
				<img src="{{ order.driver_detail.profile_pic }}" alt="{{ order.driver_detail.first_name }}">
			</a>
		</div>
		<div class="col-sm-8">
			<p class="text-bold text-theme">{{ order.driver_detail.first_name + order.driver_detail.last_name }}</p>
			<div class="rating-container">
				<div class="form-group">
					<span><label>1</label></span>&nbsp;
					<input type="radio" id="rate" name="rate" value="1" ng-model="rate">&nbsp;
					<input type="radio" id="rate" name="rate" value="2" ng-model="rate">&nbsp;
					<input type="radio" id="rate" name="rate" value="3" ng-model="rate">&nbsp;
					<input type="radio" id="rate" name="rate" value="4" ng-model="rate">&nbsp;
					<input type="radio" id="rate" name="rate" value="5" ng-model="rate" checked>&nbsp;
					<span><label>5</label></span>
				</div>
				<div class="form-group">
					<textarea ng-model="comment" class="form-control" placeholder="{{ 'EnterComment' | translate }}"></textarea>
				</div>
			</div>
		</div>
		<div class="clear clear-fix margin-to-md" >
			<div class="col-sm-6"><input type="button" ng-click="cancle()" class="btn btn-danger btn-block " value="{{ 'Cancel' | translate }}" ></div>
			<div class="col-sm-6"><input type="button" ng-click="sendRating()" class="btn btn-info btn-theme btn-block " value="{{ 'RateNow' | translate }}" ></div>
		</div>
		
	</div>
</div>