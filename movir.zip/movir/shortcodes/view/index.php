<?php
	//echo '<pre>'; print_r(session_id()); echo '</pre>';
	//echo '<pre>'; print_r($_SESSION); echo '</pre>';
	
?>
<div id="movirapp" ng-app="movirApp" ng-controller="movirAppCtrl" class="container movirapp" >

	<div class="col-lg-8 col-md-9 col-sm-12 text-danger" ng-bind="message"></div>
	<div ui-view></div>
</div>
