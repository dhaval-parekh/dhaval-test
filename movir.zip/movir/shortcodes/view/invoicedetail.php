<p class="text-danger" ng-bind="message[0]"></p>
<div  class="row " >
	<div class="col-xs-12 padding-sm">
		<p class="text-theme text-bold text-center"><label>{{ 'InvoiceDetail' | translate }}</label></p>
		<p class="text-theme text-bold text-center"><label>{{ 'OrderID' | translate }} : <span ng-bind="invoice.appointment_id"></span></label></p>
		<div class="pull-right"> {{ 'InvoiceStatus' | translate }} <label class="label {{ invoice.status_class }}" >{{ invoice.status_text | translate }}</label></div>
	</div>
	<div class="col-xs-12">
		<table class="table table-condensed">
			<tr class="text-theme">
				<th>{{ 'Detail' | translate }}</th>
				<th align="right">{{ 'Amount' | translate }}</th>
			</tr>
			<tr>
				<th>{{ 'MovingCharge' | translate }}</th>
				<td ><span ng-bind="invoice.transport_charge"></span>&nbsp;<small>ILS</small></td>
			</tr>
			<tr>
				<th>{{ 'CouponDiscount' | translate }}</th>
				<td><span ng-bind="invoice.discount"></span>&nbsp;<small>ILS</small></td>
			</tr>
			<tr>
				<th>{{ 'VAT' | translate}} (<span ng-bind="invoice.vat"></span>%)</th>
				<td><span ng-bind="invoice.vat_amount"></span>&nbsp;<small>ILS</small></td>
			</tr>
			<tr>
				<th>{{ 'Tip' | translate }}</th>
				<td><span ng-bind="tip"></span>&nbsp;<small>ILS</small></td>
			</tr>
			<tr>
				<th>{{ 'Total' | translate }}</th>
				<th><span ng-bind="invoice.amount"></span>&nbsp;<small>ILS</small></th>
			</tr>
		</table>
	</div>
	<div class="col-xs-12">
		<div class="form-group text-right ">
			<label class="text-bold text-theme lead">{{ 'AddTip' | translate }} : &nbsp;&nbsp;</label>
			<label class="text-bold text-theme lead pull-right">&nbsp;&nbsp;ILS &nbsp;&nbsp;</label>
			<input type="number" style="width:200px;" class="pull-right" id="tip" name="tip" ng-model="tip" ng-disabled="invoice.status==2 || invoice.status==4">
		</div>
	</div>
	<div class="">
		<div class="col-sm-6 col-sm-offset-3" ng-hide="invoice.status==2 || invoice.status==4">
			<div class="">
				<a href="javascript:" id="btnMakepayment" data-loading-text="{{ 'Loading' | translate }}" class="btn btn-block btn-theme btn-info btn-bg" ng-click="makePayment()">{{ 'MakePayment' | translate }}</a>
			</div>
		</div>
	</div>
</div>
