<?php
	require_once('config.php');
	$Form = new movir_form();
?>
<p class="text-danger " ng-bind="message[0]"></p>
<ul class="orderlisting">
	<li ng-repeat="order in orders"  >
		<ul class="list-item">
			<li><label class="label vehicletype {{ order.vehicle_class }}" ></label></li>
			<li>
				<p><label class="text-theme text-bold" ng-click="orderDetail(order.appointment_id)"> {{ 'OrderID' | translate }} : {{ order.appointment_id }}</label></p>
				<p><label >{{ order.driver_text }}</label></p>
				<p><label ng-bind="order.date_text"></label></p>
			</li>
			<li>
				<p><label ng-bind="order.amount_text"></label></p>
				<p><label class="label {{ order.status_class }}" > {{ order.status_text | translate }} </label></p>
				<p><a href="javascript:" class="btn btn-info btn-xs btn-block" ng-hide="!order.canreorder" ng-click="openDatechecker(order.appointment_id)" > {{ 'Reorder' | translate }}</a></label></p>
			</li> <!-- data-toggle="modal" data-target="#modalReorder"  -->
		</ul>
	</li>
</ul>
<div id="modalReorder" class="modal fade" tabindex="-1" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title">{{ 'SelectDateReorder' | translate }}</h4>
			</div>
			<div class="modal-body">
				<p ng-bind="message[1]" class="text-danger"></p>
				<div class="" > <!-- ng-hide="estimateCharge != false;" -->
					<?php echo $Form->Input('text','reorderappointmentdate',false,false,'',array('placeholder'=>"{{ 'AppointmentDateReorder' | translate }}",'ng-model'=>'reorder.appointmentdate'),array(),array('required'=>false)); ?>
				</div>
				<div class="" ng-hide="estimateCharge == false;">
					<div class="row">
						<div class="col-xs-6 ">
							<dl class="dl-horizontal">
								<dt>{{ 'MovingCharge' | translate }}</dt>
								<dd><span ng-bind="estimateCharge.transport_charge"></span>&nbsp;<small>ILS</small></dd>
								<dt>{{ 'CouponDiscount' | translate }}</dt>
								<dd><span ng-bind="estimateCharge.discount"></span>&nbsp;<small>ILS</small></dd>
								<dt>{{ 'VAT' | translate }} (<span ng-bind="estimateCharge.vat_percentage"></span>%)</dt>
								<dd><span ng-bind="estimateCharge.vat"></span>&nbsp;<small>ILS</small></dd>
								<dt>{{ 'Total' | translate }}</dt>
								<dd><span ng-bind="estimateCharge.price"></span>&nbsp;<small>ILS</small></dd>
							</dl>
						</div>
						<div class="col-xs-12 text-right">
							<?php echo $Form->Button('button','btnAddPayment',"{{ 'AddPaymentMethod' | translate }}",'btn-info',array('ng-click'=>'getCcDetailId()','data-loading-text'=>"{{ 'Loading' | translate }}")) ?>
						</div>
					</div>
				</div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button id="getEstimateReorder" type="button" ng-hide="estimateCharge != false;" class="btn btn-theme btn-info" data-loading-text="{{ 'Loading' | translate }}" ng-click="getEstimate();" ng-disabled="reorder.appointmentdate == ''">Get Estimate</button>
				<button id="placeReorder" type="button" ng-hide="estimateCharge == false;" class="btn btn-theme btn-info" data-loading-text="{{ 'Loading' | translate }}" ng-click="placeReorder();" >Place Order</button>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<div id="movir_OrderPaymentModal" class="modal fade" tabindex="-1" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<?php /*?><div class="modal-header"><h4 class="modal-title">Modal title</h4></div><?php */?>
			<div class="modal-body">
				<iframe id="iframeOrderPayment" class="iframeOrderPayment" src=""></iframe>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div><!-- /.modal -->