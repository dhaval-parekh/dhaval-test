<?php
	require_once('config.php');
	$vehicle_type_option = array(
							1=>'Mini Van',
							2=>'Pickup Truck',
							3=>'Truck',
//							0=>'Don\'t Know ?'
						);
	$order_type_option = array(
							1=>'No Lugging',
							2=>'Lugging',
						);
						
	$elevetor_option =  array('type'=>'array',
						'contant'=>array(
							''=>'Floor/Elevator',
							'-1'=>'Elevetor',
							0=>'Ground Floor',
							1=>'1st Floor',
							2=>'2nd Floor',
							3=>'3rd Floor',
							4=>'4th Floor',
							5=>'5th Floor',
						)
					);
					
	$Form = new movir_Form();

	function createNextStepButton($step,$label = '{{ "Next" | translate }}'){
		if(! (isset($step) && is_numeric($step))){ return false; }
		$Form = new movir_Form();
		$html = $Form->Button('button','nextStep_'.$step,$label,'btn btn-info',array('ng-click'=>'nextstep('.$step.')'));
		return $html;
	}
?>
<div class="row" ng-class="{'no-lugging': ordertype==1, 'lugging': ordertype==2}" style="visibility:visible;"><!--style="visibility:hidden;"-->
<?php echo $Form->Open(false,false,'form',array('onsubmit'=>'return false;')); ?>
	<div class="col-xs-12">
		<uib-accordion close-others="oneAtATime">
			<!-- Step 1 -->
			<uib-accordion-group heading="{{ 'OrderType' | translate }}" is-open="openStep == 1" is-disabled="complatedStep < 1">
				<div class="row">
					<div class="col-xs-12"><p id="movir_error_step_1" class="text-danger error-message" ng-bind="message[1]"></p></div>
					<div class="ordertype-list" >
						<div class="form-group">
							<label ng-repeat="type in resource.ordertype" class="cbx-label" ng-class="{ 'active':order.ordertype==type.value }"><input type="radio" ng-model="order.ordertype" value="{{ type.value }}" id="ordertype" name="ordertype" ><span>{{ type.text | translate }}</span></label>
						</div>
						<div class="clear"></div><hr>
					</div>
					
					<div class="col-xs-12 text-right"><?php echo createNextStepButton(2); ?></div>
				</div>
			</uib-accordion-group>
			<!-- /Step 1 -->
			<!-- Step 2 -->
			<uib-accordion-group heading="{{ 'PickupInfo' | translate }}" is-open="openStep == 2" is-disabled="complatedStep < 2"> 
				<div class="row">
					<div class="col-xs-12"><p id="movir_error_step_2" class="text-danger error-message" ng-bind="message[2]"></p></div>
					<div class="col-xs-12 text-center vehicletype-list form-group" ng-hide="true">
						<div class="form-group">
							<label ng-repeat="type in resource.vehicletype" class="cbx-label" ng-class="{ 'active': type.value==order.vehicletype }">
								<input type="radio" ng-model="order.vehicletype" value="{{ type.value }}" id="vehicletype" name="vehicletype" ><span>{{ type.text | translate }}</span>
							</label>
						</div>
					</div>
					<div class="clear"></div>
					<hr class="" ng-hide="true"/>
					<?php /*?><div class="col-xs-12"><?php echo $Form->Input('text','pickupaddress','','',false,array('ng-change'=>'setPickupAddress(this)','placeholder'=>'Pickup Address','ng-model'=>'pickAddress')); ?></div><?php */?>
					
					<div class="col-xs-12">
						<div class="row">
							<div class="col-xs-6">
								<?php echo $Form->Input('text','pickupname','','',false,array('placeholder'=>"{{ 'FullName' | translate }}",'ng-model'=>'order.pickupname')); ?>
							</div>
							<div class="col-xs-6">
								<?php echo $Form->Input('tel','pickupphone','','',false,array('placeholder'=>"{{ 'PhoneNumber' | translate }}",'ng-model'=>'order.pickupphone')); ?>
							</div>
							<div class="col-xs-12">
								<?php echo $Form->Input('text','pickupaddress','','',false,array('placeholder'=>"{{ 'PickupAddress' | translate }}",'ng-model'=>'order.pickAddress')); ?>
								<p  class="text-danger error-message" ng-bind="message['pickupcity']"></p>
							</div>
							<?php /*?><div class="col-xs-6"><h4>Add Items for move</h4></div> <?php */?>
							<div class="col-xs-12">
								<?php echo $Form->Input('text','searchproduct','',' typeahead tt-query tags ',false,array('placeholder'=>"{{ 'SearchItems' | translate }}",'ng-model'=>'productSearchQuery','autocomplete'=>'off'),array(),array('required'=>false)); //  ?>
								<p  class="text-danger error-message" ng-bind="message['product']"></p>
							</div>
						</div>
						<table class="table table-condensed ">
							<thead>
								<tr><th width="20%" ng-hide="order.ordertype!=2 || order.isAssembly!=1">{{ 'Assembly' | translate }}</th><th>{{ 'ProductName' | translate }}</th><th width="20%">{{ 'Remove' | translate }}</th></tr>
							</thead>
							<tbody>
								<tr ng-repeat="x in order.product" ng-row="{{x.id}}">
									<td ng-hide="order.ordertype!=2 || order.isAssembly!=1"><input type="checkbox" ng-model='x.assemble' ng-click="addAssembly(x.id)"  ></td>
									<td>{{ x.name }}</td>
									<td class=""><a href="javascript:" ng-click="removeProduct(x.id)" class="btn-xs text-danger" ng-value="{{x.id}}"><i class="fa fa-times"></i></a> </td>
								</tr>
							</tbody>
						</table>
					</div>
				</div>
				<!-- Order Hire Pro -->
				<div id="orderhirepro" class="orderhirepro " ng-hide="order.ordertype!=2">
					<div class="row text-center assembly-line">
						<hr/>
						<div class="col-xs-4"><?php echo $Form->Input('number','pickFloor',false,false,'',array('placeholder'=>"{{ 'FloorNumber' | translate }}",'ng-model'=>'order.pickFloor'),array(),array('required'=>false)); ?></div>
						<div class="col-xs-4">
							<div class="form-group"><label class="cbx-label" ng-class="{ 'active':order.pickupElevator==1 }"><input type="checkbox" ng-false-value="0" ng-true-value="1" ng-model="order.pickupElevator" value="1" id="pickupElevator[1]" name="pickupElevator[1]" class="ng-untouched ng-valid ng-dirty ng-valid-parse" style=""><span>{{ 'IsthereanElevator' | translate }}</span></label></div>
							<?php //echo $Form->Checkbox('pickupElevator',array(),'','',array('ng-model'=>'order.pickupElevator','ng-true-value'=>'1','ng-false-value'=>'0'),array(),array('1'=>'Pickup Elevator'),array('required'=>false)); ?>
						</div>
						<div class="col-xs-4">
							<div class="form-group"><label class="cbx-label" ng-class="{'active':order.isAssembly==1}"><input type="checkbox" ng-false-value="0" ng-true-value="1" ng-model="order.isAssembly" value="1" id="isAssembly[1]" name="isAssembly[1]" class="ng-untouched ng-valid ng-dirty ng-valid-parse" style=""><span>{{ 'Assembly' | translate }}</span></label></div>
							<?php //echo $Form->Checkbox('isAssembly',array(),'','',array('ng-model'=>'order.isAssembly','ng-true-value'=>'1','ng-false-value'=>'0'),array(),array('1'=>'Assembly ?'),array('required'=>false)); ?>
						</div>
					</div>
				</div>
				<div class="row">
					<hr>
					<div class="col-xs-12 text-right">
						<?php  echo createNextStepButton(1,'{{ "Back" | translate }}'); ?>
						<?php  echo createNextStepButton(3); ?>
					</div>
				</div>
				<!-- /Order Hire Pro -->
			</uib-accordion-group>
			<!-- /Step 2 -->
			<!-- Step 3 -->
			<uib-accordion-group heading="{{ 'DropoffInfo' | translate }}" is-open="openStep == 3" is-disabled="complatedStep < 3">
				<div class="row">
					<div class="col-xs-12"><p id="movir_error_step_3" class="text-danger error-message" ng-bind="message[3]"></p></div>
					<div class="col-xs-6">
						<?php echo $Form->Input('text','dropname','','',false,array('placeholder'=>"{{ 'FullName' | translate }}",'ng-model'=>'order.dropname')); ?>
					</div>
					<div class="col-xs-6">
						<?php echo $Form->Input('tel','dropphone','','',false,array('placeholder'=>"{{ 'PhoneNumber' | translate }}",'ng-model'=>'order.dropphone')); ?>
					</div>
					<div class="col-xs-12"><?php echo $Form->Input('text','dropaddress','','',false,array('placeholder'=>"{{ 'DropoffAddress' | translate}}",'ng-model'=>'order.dropAddress')); ?></div>
					<div class="col-xs-12">
						<div class="row assembly-line text-center " ng-hide="order.ordertype!=2"> <!-- .column-5 -->
							<div class="col-xs-6"><?php echo $Form->Input('number','dropFloor',false,false,'',array('placeholder'=>"{{ 'FloorNumber' | translate }}",'ng-model'=>'order.dropFloor'),array(),array('required'=>false)); ?></div>
							<div class="col-xs-6">
								<div class="form-group">
									<label class="cbx-label" ng-class="{'active': order.phpdropElevator==1 }"><input type="checkbox" ng-false-value="0" ng-true-value="1" ng-model="order.phpdropElevator" value="1" id="dropElevator" name="dropElevator" class="" ><span>{{ 'IsthereanElevator' | translate }}</span></label>
								</div>
								<?php //echo $Form->Checkbox('dropElevator',array(),'','',array('ng-model'=>'order.phpdropElevator','ng-true-value'=>'1','ng-false-value'=>'0'),array(),array('1'=>'Drop Elevator'),array('required'=>false)); ?>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<hr>
					<div class="col-xs-12 text-right">
						<?php  echo createNextStepButton(2,'{{ "Back" | translate }}'); ?>
						<?php  echo createNextStepButton(4,'{{ "GetEstimate" | translate }}'); ?>
					</div>
				</div>
			</uib-accordion-group>
			<!-- /Step 3 -->
			<!-- Step 4 -->
			<uib-accordion-group heading="{{ 'EstimatePrice' | translate }}" is-open="openStep == 4" is-disabled="complatedStep < 4">
				<p id="movir_error_step_3" class="text-danger error-message" ng-bind="message[4]"></p>
				<div id="estimateCharge" class="row"  ng-hide="estimateCharge == false" > <!-- ng-bind='estimateCharge.html' -->
					<div class="col-xs-6">
						<address>
							<strong>{{ "PickupAddress" | translate }}</strong><br>
							<span ng-bind="order.pickAddress"></span><br>
							<span ng-hide="order.ordertype != 2">{{ "FloorNumber" | translate }} : <small >{{ (isNaN(order.pickFloor)?0:order.pickFloor) }}</small>,  {{ "Elevator" | translate }} : <small >{{ (order.pickupElevator==1?'YES':'NO') }}</small></span>
						</address>
					</div>
					<div class="col-xs-6">
						<address>
							<strong>{{ "DropoffAddress" | translate }}</strong><br>
							<span ng-bind="order.dropAddress"></span><br>
							<span ng-hide="order.ordertype != 2" >{{ "FloorNumber" | translate }} : <small> {{ (isNaN(order.dropFloor)?0:order.dropFloor) }} </small>,  {{ "Elevator" | translate }} : <small>{{ (order.dropElevator==1?'YES':'NO') }}</small></span>
						</address>
					</div>
					<div class="clear"></div>
					<hr>
					<div class="col-xs-6">
						<table class="table">
							<tbody>
								<tr>
									<th>#</th>
									<th>{{ 'ProductName' | translate }}</th>
									<th ng-hide="order.isAssembly != 1">{{ 'Assembly' | translate }}</th>
								</tr>
								<tr ng-repeat="pro in order.product">
									<td>{{ pro.index }}</td>
									<td>{{ pro.name }}</td>
									<td ng-hide="order.isAssembly != 1">{{ (pro.assemble?'YES':'NO') }}</td>
								</tr>
							</tbody>
						</table>
					</div>
					<div class="col-xs-6 pull-right">
						<dl class="dl-horizontal">
							<dt>{{ 'MovingCharge' | translate }}</dt>
							<dd><span ng-bind="estimateCharge.transport_charge"></span>&nbsp;<small>ILS</small></dd>
							<dt>{{ 'CouponDiscount' | translate }}</dt>
							<dd><span ng-bind="estimateCharge.discount"></span>&nbsp;<small>ILS</small></dd>
							<dt>{{ 'VAT' | translate}} (<span ng-bind="estimateCharge.vat_percentage"></span>%)</dt>
							<dd><span ng-bind="estimateCharge.vat"></span>&nbsp;<small>ILS</small></dd>
							<dt>{{ 'Total' | translate }}</dt>
							<dd><span ng-bind="estimateCharge.price"></span>&nbsp;<small>ILS</small></dd>
						</dl>
					</div>
				</div>
				
				
				<div class="row">
					<div class="col-xs-12" ng-hide="estimateCharge == false">
						<div class="row">
							<div class="col-sm-6">
								<?php echo $Form->Input('text','appointmentdate',false,false,'',array('placeholder'=>"{{ 'AppointmentDate' | translate }}",'ng-model'=>'order.appointmentdate'),array(),array('required'=>false)); ?>
							</div>
							<div class="col-sm-6">
								<div class="col-xs-7">
									<?php 
										$coupon_html = array();
										$coupon_html['before_control'] = '<div class="input-group">';
										$coupon_html['after_control'] = '<span class="input-group-btn"><button class="btn btn-info" ng-hide="couponverified == true" ng-click="verifyCoupon();" type="button"><i class="glyphicon glyphicon-refresh"></i></button></span></div>';
										echo $Form->Input('text','couponcode',false,false,'',array('placeholder'=>"{{ 'Coupon' | translate }}",'ng-disabled'=>'couponverified == true','ng-model'=>'order.coupon'),$coupon_html,array('required'=>false)); 
									?>
								</div>
								<div class="col-xs-5">
									<?php echo $Form->Button('button','btnAddPayment',"{{ 'AddPaymentMethod' | translate }}",'btn-info',array('ng-click'=>'getCcDetailId()','data-loading-text'=>"{{ 'Loading' | translate }}")) ?>
								</div>
							</div>
						</div>
					</div>
					<div class="col-xs-12 text-right pull-right">
						<?php echo createNextStepButton(3,'{{ "Back" | translate }}'); ?>
						<?php echo $Form->Button('button','btnMovirSubmit',"{{ 'PlaceOrder' | translate }}",'btn btn-info',array('data-loading-text'=>"{{ 'Loading' | translate }}",'ng-click'=>'placeOrder()')); ?>
					</div>
				</div>
			</uib-accordion-group>
			<!-- /Step 4 -->
		</uib-accordion>
	</div>
<?php echo $Form->Close(); ?>
	<div id="movir_OrderPaymentModal" class="modal fade" tabindex="-1" role="dialog">
		<div class="modal-dialog">
			<div class="modal-content">
				<?php /*?><div class="modal-header"><h4 class="modal-title">Modal title</h4></div><?php */?>
				<div class="modal-body">
					<iframe id="iframeOrderPayment" class="iframeOrderPayment" src=""></iframe>
				</div>
			</div><!-- /.modal-content -->
		</div><!-- /.modal-dialog -->
	</div><!-- /.modal -->
</div>
<script type="text/javascript">
function initMapDirection(){
	
	var pickupaddress = document.getElementById('pickupaddress');
	var dropaddress = document.getElementById('dropaddress');
	
	
	if(pickupaddress){
		var autocomplete_pickupaddress = new google.maps.places.Autocomplete(pickupaddress);
		autocomplete_pickupaddress.addListener('place_changed', function() {
			//var place = autocomplete_pickupaddress.getPlace();
			var scope = angular.element(document.getElementById('movirapp')).scope();
			scope.$apply(function(){
				scope.$$childHead.setPickupAddress(pickupaddress.value);
				
			});
		});
	}
	if(dropaddress){
		var autocomplete_dropaddress = new google.maps.places.Autocomplete(dropaddress);	
		autocomplete_dropaddress.addListener('place_changed', function() {
			//var place = autocomplete_dropaddress.getPlace();
			var scope = angular.element(document.getElementById('movirapp')).scope();
			scope.$apply(function(){
				scope.$$childHead.setDropAddress(dropaddress.value)
			});
		});
	}
}
</script>