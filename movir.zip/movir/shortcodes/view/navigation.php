<?php ?>

<nav class="navbar navbar-default">
	<!-- Brand and toggle get grouped for better mobile display -->
	<div class="navbar-header">
		<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#movir-header-navigation" aria-expanded="false"> 
			<span class="sr-only">Movir Navigation</span> 
			<span class="icon-bar"></span> 
			<span class="icon-bar"></span> 
			<span class="icon-bar"></span> 
		</button>
		<?php /*?><a class="navbar-brand" href="#"><img alt="Movir" src="..."></a> <?php */?>
	</div>
	<!-- Collect the nav links, forms, and other content for toggling -->
	<div class="collapse navbar-collapse" id="movir-header-navigation">
		<ul class="nav navbar-nav">
			<li ng-repeat="nav in navigation"><a href="#" ui-sref="{{ nav.href }}">{{ nav.text | translate }}</a></li>
		</ul>
		<ul class="nav navbar-nav navbar-right">
			<li class="dropdown">
				<a href="javascript:" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">{{ 'ChangeLanguage' | translate }} <span class="caret"></span></a>
				<ul class="dropdown-menu">
					<li ng-repeat="(localeId, langName) in language.available">
						<a href="javascript:" ng-click="language.set(localeId,$event)">{{ langName }}</a>
					</li>
				</ul>
			</li>
		</ul>
		
	</div>
	<!-- /.navbar-collapse --> 
</nav>
