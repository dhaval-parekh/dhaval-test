<div class="" style="margin:100px;" >
	<p class="text-center text-info lead">Please wait, we are locating your nearest personal mover…</p>
	<div class="loding"></div>
</div>