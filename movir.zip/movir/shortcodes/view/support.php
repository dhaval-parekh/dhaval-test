<div class="col-sm-8 col-sm-offset-2">
	<a class="jumbotron text-center" href="mailto:support@movir.com">
		<p><i class="glyphicon glyphicon-envelope text-theme"></i> Email</p>
		<p>support@movir.com</p>
	</a>
</div>
