<p class="text-danger" ng-bind="message[0]"></p>
<div  class="row " >
	<div class="padding-sm col-xs-12">
		<p class="text-theme text-bold text-center"><label>{{ 'OrderID' | translate }} : <span ng-bind="order.appointment_id"></span></label></p>
		<p class="text-thin">
			<label class="pull-left" ng-bind="order.date_text"></label>
			<label class="pull-right label {{ order.status_class }}" >{{ order.status_text | translate }}</label>
		</p>
	</div>
	<div class="col-xs-6">
		<address>
		<strong>{{ "PickupAddress" | translate }}</strong><br>
		<span ng-bind="order.pickup_address"></span><br>
		<span ng-hide="order.order_type != 2">{{ "FloorNumber" | translate }} : <small ng-bind="order.pickup_floor" ></small>,  {{ "Elevator" | translate }}  : <small >{{ order.pickup_elevator==1?'YES':'NO' }}</small></span>
		</address>
	</div>
	<div class="col-xs-6">
		<address>
		<strong>{{ "DropoffAddress" | translate }}</strong><br>
		<span ng-bind="order.drop_address"></span><br>
		<span ng-hide="order.order_type != 2" >{{ "FloorNumber" | translate }} : <small ng-bind="order.drop_floor"></small>,  {{ "Elevator" | translate }}  : <small>{{ order.drop_elevator==1?'YES':'NO' }}</small></span>
		</address>
	</div>
	<div class="clear"></div>
	<hr>
	<div class="col-xs-6">
		<table class="table">
			<tbody>
				<tr>
					<th>#</th>
					<th>{{ 'ProductName' | translate }}</th>
					<th ng-hide="order.order_type != 2">{{ 'Assembly' | translate }}</th>
				</tr>
				<tr ng-repeat="product in order.product_list">
					<td >{{ product.index }}</td>
					<td>{{ product.product_name }}</td>
					<td ng-hide="order.order_type != 2">{{ product.assemble==true?'YES':'NO' }}</td>
				</tr>
			</tbody>
		</table>
	</div>
	<div class="col-xs-6 pull-right">
		<dl class="dl-horizontal">
			<dt>{{ 'MovingCharge' | translate }}</dt>
			<dd><span ng-bind="order.transport_charge"></span>&nbsp;<small>ILS</small></dd>
			<dt>{{ 'CouponDiscount' | translate }}</dt>
			<dd><span ng-bind="order.discount"></span>&nbsp;<small>ILS</small></dd>
			<dt>{{ 'VAT' | translate}} (<span ng-bind="order.vat_percentage"></span>%)</dt>
			<dd><span ng-bind="order.vat"></span>&nbsp;<small>ILS</small></dd>
			<dt>{{ 'Total' | translate }}</dt>
			<dd><span ng-bind="order.amount"></span>&nbsp;<small>ILS</small></dd>
		</dl>
	</div>
	<div class="">
		<div class="col-sm-6 col-sm-offset-3" ng-hide="!(order.status==1 || invoice.status==2)">
			<div class="">
				<a href="javascript:" id="btnCancleOrder" data-loading-text="{{ 'Loading' | translate }}" class="btn btn-block btn-danger btn-bg" ng-click="cancleOrder()">{{ 'CanceledOrder' | translate }}</a>
			</div>
		</div>
	</div>
</div>
