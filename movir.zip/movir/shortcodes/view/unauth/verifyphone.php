<?php
	require_once('../config.php');
	$Form = new movir_Form();
?>
<div class="login-container">
	<div id="login" class="col-sm-4 " style="margin:0 auto; float:none;">
		<?php echo $Form->Open('','','',array('onsubmit'=>'return false;')); ?>
			<h3 id="logintitle">{{ 'VerifyandLogin' | translate }} </h3>
			<p class="text-danger" id="loginmessage"><?php echo isset($message)?$message:false;?></p>
			<?php
				echo $Form->Input('number','code',false,'','',array('placeholder'=>"{{ 'Code' | translate }}",'ng-model'=>'code'));
				echo '<a class="text-theme" ui-sref="login">{{ "HaveNoCode" | translate }}</a>';
				echo $Form->Button('submit','submit','{{ "Verify" | translate }}','btn-theme pull-right',array('data-loading-text'=>"{{ 'Loading' | translate }}",'ng-click'=>'submit()'));
			?>
		<?php echo $Form->Close();?>
		<!-- form --> 
		<!-- content --> 
	</div>
</div>
