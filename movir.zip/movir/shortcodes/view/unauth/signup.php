<?php
	require_once('../config.php');
	$Form = new movir_Form();
?>
<div class="login-container">
	<div id="login" class="col-sm-4 " style="margin:0 auto; float:none;">
		<?php echo $Form->Open('','','',array('onsubmit'=>'return false;')); ?>
			<h3 id="logintitle">{{ "Signup" | translate }}</h3>
			<p class="text-danger" id="loginmessage"><?php echo isset($message)?$message:false;?></p>
			<?php
				echo $Form->Input('text','name',false,'','',array('placeholder'=>"{{ 'FullName'  | translate}}",'ng-model'=>'name'));
				echo $Form->Input('email','email',false,'','',array('placeholder'=>"{{ 'Emailaddress' | translate }}",'ng-model'=>'email'));
				echo $Form->Input('tel','phone',false,'','',array('placeholder'=>"{{ 'PhoneNumberEnterWithCountryCode' | translate }}",'ng-model'=>'phone'));
				echo '<a class="text-theme" ui-sref="login">{{ "AlreadyHaveAccount" | translate }}</a>';
				echo $Form->Button('submit','submit','{{ "Signup" | translate }}','btn-theme pull-right',array('data-loading-text'=>"{{ 'Loading' | translate }}",'ng-click'=>'getVerificationCode()'));
			?>
		<?php echo $Form->Close();?>
		<!-- form --> 
		<!-- content --> 
	</div>
</div>
