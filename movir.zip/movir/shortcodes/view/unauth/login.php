<?php
	require_once('../config.php');
	$Form = new movir_Form();
?>
<div class="login-container">
	<div id="login" class="col-sm-4 " style="margin:0 auto; float:none;">
		<?php echo $Form->Open('','','',array('onsubmit'=>'return false;')); ?>
			<h3 id="logintitle">{{ 'Login' | translate  }} </h3>
			<p class="text-danger" id="loginmessage"><?php echo isset($message)?$message:false;?></p>
			<?php
				echo $Form->Input('tel','phone',false,'','',array('placeholder'=>"{{ 'PhoneNumberEnterWithCountryCode' | translate }}",'ng-model'=>'phone'));
				echo '<a class="text-theme" ui-sref="signup">{{ "NewUser" | translate }}</a>';
				echo $Form->Button('submit','submit','{{ "Login" | translate }}','btn-theme pull-right',array('data-loading-text'=>"{{ 'Loading' | translate }}",'ng-click'=>'getVerificationCode()'));
			?>
		<?php echo $Form->Close();?>
		<!-- form --> 
		<!-- content --> 
	</div>
</div>
