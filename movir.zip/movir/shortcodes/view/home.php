<?php
	require_once('config.php');
?>
<div class="col-lg-8 col-md-9 col-sm-12" style="margin:0 auto; float:none;">
	<!-- Navigation View -->
	<div ui-view="navigation"></div>
	<!-- Main View -->
	<div ui-view><?php include('orderplace.php')?></div>
</div>