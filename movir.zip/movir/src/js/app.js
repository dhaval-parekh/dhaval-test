// JavaScript Document

//	Main Application Controller
movirapp.controller('movirAppCtrl',['$http','$rootScope', '$scope', '$state',  '$window', '$document', '$timeout', '$translate', 
function ($http, $rootScope, $scope, $state,  $window, $document, $timeout,$translate) {
	//	Call Api function Over
	$rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {});
	$rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {
	});
	
	$rootScope.language = {
		// Handles language dropdown
		listIsOpen: false,
		// list of available languages
		available: {
			'en': 'English',
			'hw': 'Hebrew',
		},
		// display always the current ui language
		init: function () {
			var proposedLanguage = $translate.proposedLanguage() || $translate.use();
			var preferredLanguage = $translate.preferredLanguage();
			// we know we have set a preferred one in app.config
			$rootScope.language.selected = $rootScope.language.available[(proposedLanguage || preferredLanguage)];
		},
		set: function (localeId, ev) {
			console.log(localeId);
			console.log($translate.use(localeId));
			$rootScope.language.selected = $rootScope.language.available[localeId];
			$rootScope.language.listIsOpen = !$rootScope.language.listIsOpen;
		}
		
	};
	$rootScope.$on('$translateChangeSuccess', function () {
		$translate.refresh();
	});
	$rootScope.language.init();
	
}]);


//	Login controller
movirapp.controller('ctrlLogin',['$rootScope', '$scope', '$state',
	function($rootScope, $scope, $state){
		$scope.init = function(){
			//	Maintain state of application
			var session = $rootScope.session;
			if(typeof(session.user) != 'undefined' && typeof(session.user.token) != 'undefined'){
				$state.go('app');
			}else if(! isNaN($rootScope.session.verificationcode)){
				//	If verification code exists then send to `Verification screen`
				$state.go('verify');
			}
		}
		$scope.init();
		
		$scope.getVerificationCode = function(){
			var action = 'customerLogin';
			var data = new Object();
			data.phone = $scope.phone;
			var button = jQuery('#submit','#movirapp').button('loading');
			$rootScope.callApi(action,data,function(data){
				jQuery(button).button('reset');
				if(data.errFlag != 0){ $rootScope.message = data.errMsg; return false; }
				data = data.data;
				$rootScope.session.user = new Object()
				$rootScope.session.user.userid = data.userid;
				$rootScope.session.verificationcode = data.verificationcode;
				$rootScope.saveSession();
				$state.go('verify');
			});
			return false;
		}
}]);	// Login Controller Over 

// Signup Controller
movirapp.controller('ctrlSignup',['$rootScope', '$scope', '$state',
	function($rootScope, $scope, $state){
		
		$scope.init = function(){
			//	Maintain state of application
			var session = $rootScope.session;
			if(typeof(session.user) != 'undefined' && typeof(session.user.token) != 'undefined'){
				$state.go('app');
			}else if(! isNaN($rootScope.session.verificationcode)){
				//	If verification code exists then send to `Verification screen`
				$state.go('verify');
			}
		}
		$scope.init();
		
		$scope.getVerificationCode = function(){
			var action = 'customerSignup';
			var data = new Object();
			data.name = $scope.name
			data.email = $scope.email;
			data.phone = $scope.phone;
			var button = jQuery('#submit','#movirapp').button('loading');
			$rootScope.callApi(action,data,function(data){
				jQuery(button).button('reset');
				if(data.errFlag != 0){ $rootScope.message = data.errMsg; return false; }
				data = data.data;
				$rootScope.session.user = new Object()
				$rootScope.session.user.userid = data.userid;
				$rootScope.session.verificationcode = data.verificationcode;
				$rootScope.saveSession();
				$state.go('verify');
				
			});
			return false;
		}
}]);	// Signup Controller Over 

//	Verification Controller
movirapp.controller('ctrlVerify',['$rootScope','$scope','$state',
	function($rootScope,$scope,$state){
		$scope.init = function(){
			//	If verification code NOT exists then send to `Login screen`
			if(isNaN($rootScope.session.verificationcode)){
				$state.go('login');
			}
		}
		$scope.init();
		$scope.submit = function(){
			if($rootScope.session.verificationcode != $scope.code){	
				$rootScope.message = 'Invalid code has submited ! Please try again';
				return false;
			}
			$rootScope.message  = '';
			var action = 'verifycustomer';
			var data = new Object();
			data.userid = $rootScope.session.user.userid;
			data.ent_dev_id = 'web application';
			data.ent_device_type = $rootScope.devicetype ; // 
			data.ent_push_token = $rootScope.sessionid;
			
			var button = jQuery('#submit','#movirapp').button('loading');
			$rootScope.callApi(action,data,function(data,status){
				jQuery(button).button('reset');
				if(data.errFlag != 0){ $rootScope.message = data.errMsg; return false; }
				//data = data.data;
				var user = new Object();
				user = data;
				delete user.errFlag;
				delete user.errMsg;
				delete user.errNum;
				delete user.flag;
				$rootScope.session.user = user;
				$rootScope.session.verificationcode = false;
				$rootScope.saveSession();
				
				
				//	Start Socket
				$rootScope.init();
				
			});
		}
	}
]);	//	Verification controller Over


//	navigation Controller (Maintain Top navigation system)
movirapp.controller('ctrlNavigation',['$scope',function($scope){
	$scope.navigation = new Object();
	$scope.navigation.home 			= {'text':'Home','href':'app'};
	$scope.navigation.track 		= {'text':'LiveTracking','href':'app.track'};
	$scope.navigation.orderhistory 	= {'text':'OrderHistory','href':'app.orderhistory'};
	$scope.navigation.invoice 		= {'text':'Invoice','href':'app.invoice'};
	$scope.navigation.account 		= {'text':'Account','href':'app.account'};
	$scope.navigation.support 		= {'text':'Support','href':'app.support'};
	
	//$scope.navigation.orderplace	= {'text':'Place Order',href:'app'};
}]);	//	Navigation Controller

//	After Auth Application Controller (Also Order Place Controller )
movirapp.controller('ctrlOrderplace',['$rootScope','$scope','$state',
	function($rootScope, $scope,$state){
		// Resource
		$scope.resource = new Object();
		//	Order type
		$scope.resource.ordertype = new Object();
		$scope.resource.ordertype[0] = {'text':'DoItYourself','value':1};
		$scope.resource.ordertype[1] = {'text':'HireAPro',	'value':2};
		
		//	Vehicle type
		$scope.resource.vehicletype = new Object();
		$scope.resource.vehicletype[1] = {'text':'Minivan',	'value':1};
		$scope.resource.vehicletype[2] = {'text':'PickupTruck','value':2};
		$scope.resource.vehicletype[3] = {'text':'Truck',		'value':3};
		
		// Order 
		$scope.order = new Object();
		$scope.order.ordertype = 1;
		$scope.order.vehicletype = 1;
		$scope.order.pickAddress;
		$scope.order.dropAddress;
		$scope.order.city = false;
		$scope.order.dropcity = false;
		$scope.order.zipcode = false;
		$scope.order.dropzipcode = false;
		$scope.order.pickFloor = null;
		$scope.order.dropFloor = null;
		$scope.order.pickupElevator = 0;
		$scope.order.dropElevator = 0;
		$scope.order.isAssembly = 0;
		$scope.order.product = new Object();
		$scope.order.assembleProduct = new Object();
		$scope.order.price = new Object();
		$scope.order.estimateCharge = false;
		$scope.order.appointmentdate = false;
		$scope.order.ccdetailid = false;
		$scope.couponverified = false;
		// Accordiant
		$scope.oneAtATime = true;
		$scope.complatedStep = 1;
		$scope.openStep = 1;
		
		//	Error Message
		$scope.message = [];
		
		// init function 
		$scope.init = function(){
			//	If verification code NOT exists then send to `Login screen`
			$rootScope.checkSession();
		};
		$scope.init();
		// Add Product Function 
		$scope.addProduct = function (item){
			
			var id = item.product_id;
			$scope.order.product[id] = new Object();

			$scope.order.product[id]['id'] = id;
			$scope.order.product[id]['name'] = item.product_name;

			$scope.order.product[id]['assemble'] = false;
			
			$scope.order.product[id]['minivan'] = item.minivan==1?true:false;
			$scope.order.product[id]['pickup'] = item.pickup==1?true:false;
			$scope.order.product[id]['truck'] = item.truck==1?true:false;


			if($scope.order.vehicletype != $scope.suggestVehicleType()){
				//if(confirm('Product does not support vehicle type? Do you want to change')){
					var vehicletype = $scope.suggestVehicleType(true);
					$scope.message[2] = 'Vehicle type "'+$scope.resource.vehicletype[vehicletype].text+'" selected';
				//}else{
				//	return false;	
				//}
			}
		}	//	Add Prodcut Over
		
		//	Suggest Vehicle Type 
		$scope.suggestVehicleType = function(set){
			var product = $scope.order.product;
			var vehicleType = 1;
			var count = new Object();
			count.minivan = 0;
			count.pickup = 0;
			count.truck = 0;
			for(i in product){
				if(product[i]['minivan']){
					count.minivan++;	
				}else{
					// If not suitable for `minivan`
					if(product[i]['pickup']){
						count.pickup++;	
					}else{
						// If not suitable for `pickup truck`
						if(product[i]['truck']){	count.truck++;	}
					}
				}
			}
			if(count.minivan > 0){	vehicleType = 1; }
			if(count.pickup > 0){	vehicleType = 2; }
			if(count.truck > 0){	vehicleType = 3; }
			if(typeof(set) != 'undefined' && set){
				$scope.order.vehicletype = vehicleType;
			}
			return vehicleType;
		}
		
		// Remove Product Function 
		$scope.removeProduct = function (id){
			delete($scope.order.product[id]);
			delete($scope.order.assembleProduct[id]);
			$scope.suggestVehicleType(true);
		}
		
		// Add Assemble
		$scope.addAssembly = function(id){
			$scope.order.assembleProduct[id] = $scope.order.product[id]; // new Object();
			if($scope.order.product[id]['assemble']){
				$scope.order.product[id]['assemble'] = true;
			}else{
				$scope.removeAssembleProduct(id);
			}
		}

		// Remove Product Function 
		$scope.removeAssembleProduct = function (id){
			delete($scope.order.assembleProduct[id]);
			$scope.order.product[id]['assemble'] = false;
		}
		
		//	Set Pickup Address
		$scope.setPickupAddress = function(address){
			$scope.order.pickAddress = address;
			$scope.validateCity(address,function(payload,status){
				$scope.order.city = '';
				$scope.order.zipcode = '';
				$scope.message.pickupcity = '';
				if(payload.errFlag != 0){
					$scope.message.pickupcity = payload.errMsg;
					return false;
				}
				$scope.order.city = payload.data.city;
				$scope.order.zipcode = payload.data.zipcode;
			});
		}
		
		//	Set Drop Address
		$scope.setDropAddress = function(address){
			$scope.order.dropAddress = address;
			$scope.validateCity(address,function(payload,status){
				$scope.order.dropcity = '';
				$scope.order.dropzipcode = '';
				//if(payload.errFlag != 0){
				//	$scope.message.pickupcity = payload.errMsg;
				//	return false;
				//}
				$scope.order.dropcity = payload.data.city;
				$scope.order.dropzipcode = payload.data.zipcode;
			});
		}
		
		//	Validate City function
		$scope.validateCity = function(address,callback){
			var geocoder = new google.maps.Geocoder();
			//var address = $scope.order.pickAddress;
			var action = 'validateCountry';
			geocoder.geocode( { 'address': address}, function(results, status) {
				if (status == google.maps.GeocoderStatus.OK) {
					var latitude = results[0].geometry.location.lat();
					var longitude = results[0].geometry.location.lng();
					var data = new Object();
					var user = $rootScope.session.user;
					data.userid = user.userid;
					data.token = user.token;
					data.latitude = latitude;
					data.longitude = longitude;
					$rootScope.callApi(action,data,function(payload,status){
						if(typeof(callback) == 'function'){
							callback(payload,status)	;
						}
						
					});
				}
			});
		}	//	Validate city function over 
		
		//	Get CC detail Id
		$scope.getCcDetailId = function(){
			var btn = jQuery('#btnAddPayment','#movirapp').button('loading');
			var action = 'ganarateccdetail';
			var data = new Object();
			data.userid = $rootScope.session.user.userid;
			data.token= $rootScope.session.user.token;
			
			var payment_modal =	jQuery('#movir_OrderPaymentModal','#movirapp');
			var payment_iframe = jQuery('#iframeOrderPayment','#movirapp')
			if($scope.order.ccdetailid){
				payment_iframe.attr('src',$scope.paymentUrl);
				payment_modal.modal('show');
				jQuery(btn).button('reset');
				return false;	
			}
			
			$rootScope.callApi(action,data,function(payload){
				jQuery(btn).button('reset');
				if(payload.errFlag != 0){ 
					$scope.message[4] = payload.errMsg; 
					return false; 
				}
				
				$scope.order.ccdetailid = payload.data.ccdetailid;
				$scope.paymentUrl = payload.data.url;
				
				payment_iframe.attr('src',$scope.paymentUrl);
				payment_modal.modal('show');
			});
		}
		
		//	check appointment date
		$scope.checkAppointmentDate = function(date){
			var action = 'checkappointmentdate';
			var request = new Object();
			request.userid = $rootScope.session.user.userid;
			request.token = $rootScope.session.user.token;
			request.date = date;
			$rootScope.callApi(action,request,function(payload,status){
				$scope.order.appointmentdate = '';
				$scope.message[4] = '';
				if(payload.errFlag != 0){ $scope.message[4] = payload.errMsg; return false; }
				$scope.order.appointmentdate = date;
			});
		}	//	check appointment date Over
		
		// Set Estimate Charge
		$scope.setEstimateCharge = function(charge){
			if(charge == false){
				$scope.estimateCharge = false;
				return false;	
			}
			$scope.estimateCharge = new Object();
			$scope.estimateCharge['transport_charge'] = charge.transport_charge;
			$scope.estimateCharge['discount'] = charge.discount;
			$scope.estimateCharge['vat_percentage'] = charge.vat_percentage;
			$scope.estimateCharge['vat'] = charge.vat;
			$scope.estimateCharge['price'] = charge.price;
			
			//	Datetime picker
			jQuery(function () {
				jQuery('#appointmentdate','#movirapp').datetimepicker({
          			format:'MM-DD-YYYY HH:mm:ss',
				}).on('dp.hide',function(e){
					var date = jQuery(this).val();
					$scope.checkAppointmentDate(date);
				});
			});
			var count = 0;
			for(i in $scope.order.product){
				$scope.order.product[i].index = ++count;
			}
			
		}	//	set Estimate charge over
		
		// Ganrate Request fuction (use to create reuqest for estimate price or order place api)
		$scope.ganarateRequest = function(placeOrder){
			var request = new Object();
			request.ordertype = $scope.order.ordertype;
			request.pickupaddress = $scope.order.pickAddress;
			request.dropaddress = $scope.order.dropAddress;
			request.vechicletype = $scope.order.vehicletype;
			request.pickupcity = $scope.order.city;
			request.pickupzipcode = $scope.order.zipcode;
			
			request.dropcity = $scope.order.dropcity;
			request.dropzipcode = $scope.order.dropzipcode;
			
			request.coupon = typeof($scope.order.coupon)!='undefined'?$scope.order.coupon:'';
			request.products = '';
			for(i in $scope.order.product){
				if(request.products == ''){
					request.products +=  i;
				}else{
					request.products +=  ','+i;
				}
			}
			if($scope.order.ordertype == 2){
				request.pickupfloor = $scope.order.pickFloor;
				request.dropfloor = $scope.order.dropFloor;
				request.pickup_elevator = $scope.order.pickupElevator;
				request.drop_elevator = $scope.order.dropElevator;
				request.assemble = $scope.order.isAssembly;
				if(request.assemble == 1){
					request.assemble_product = '';
					for(i in $scope.order.assembleProduct){
						if(request.assemble_product == ''){
							request.assemble_product +=  i;
						}else{
							request.assemble_product +=  ','+i;
						}
					}	
				}
			}
			// Not used yet 
			if($scope.order.ordertype == 2){
				request.hydraulic = 0;
				request.drop_hydraulic = 0;
			}
				
				
			if(typeof(placeOrder) != 'undefined' && placeOrder){
				request.userid = $rootScope.session.user.userid;
				request.token = $rootScope.session.user.token;
				
				request.ccdetailid = $scope.order.ccdetailid;
				request.appointment_date = $scope.order.appointmentdate;
				request.ccdetailid = $scope.order.ccdetailid;
				
				request.pickupname = $scope.order.pickupname;
				request.pickupphone = $scope.order.pickupphone;
				request.dropname = $scope.order.dropname;
				request.dropphone = $scope.order.dropphone;
				
				//	Appointment Type = 1. Do it your Self 2. Hire a Pro
				request.appointment_type = $scope.order.ordertype;
				//	Always Future order 
				request.ordertype = 2;
				
				
			}
			return request;
		}	// Ganrate Request fuction over 
		
		//	get Estimate charge 
		$scope.getEstimateCharge = function(){
			var btn = jQuery('#btnMovirSubmit','#movirapp').button('loading');
			$scope.setEstimateCharge(false);
			var request = $scope.ganarateRequest();
			
			$rootScope.callApi('getestimate',request,function(data){
				jQuery(btn).button('reset');
				if(data.errFlag != 0){ 
					$scope.message[4] = data.errMsg; 
					return false; 
				}
				var charges = data.data;
				$scope.setEstimateCharge(charges);	
			});
		}	//	get Estimate charge Order
		
		//	Verify Coupon code
		$scope.verifyCoupon = function(){
			var action = 'verifycoupon';
			var request = new Object();
			request.coupon = $scope.order.coupon;
			request.totalcharge = $scope.estimateCharge.price;
			
			$rootScope.callApi(action,request,function(payload){
				console.log(payload);
				if(payload.errFlag != 0){ 
					$scope.message[3] = payload.errMsg; 
					return false; 
				}
				$scope.couponverified = true;
				$scope.getEstimateCharge();
			});
		}	//	verify Coupon code
		
		//	Next Step button click event
		$scope.nextstep = function(step){
			switch(step){
				case 1:
					break;
				case 2:
						if(! ($scope.order.ordertype==1 || $scope.order.ordertype==2)){
							$scope.message[1] = 'Please Select Order type'
							return false;	
						}
						$scope.message[1] = '';
						autocomplate_product();
						initMap(initMapDirection);
					break;
				case 3:
						var product_len = Object.keys($scope.order.product).length;
						
						if($scope.order.pickupname=='' || $scope.order.pickupname==null ){
							$scope.message[2] = 'Please Enter Full name';	
							return false;
						}else if($scope.order.pickupphone=='' || isNaN($scope.order.pickupphone) || ($scope.order.pickupphone).length < 6 ){
							$scope.message[2] = 'Please Enter Phone';	
							return false;
						}
						if($scope.order.pickAddress=='' || $scope.order.pickAddress==null ){
							$scope.message[2] = 'Please Enter pickup address';
							return false;
						}else{
							if(! $scope.order.city){
								$scope.message[2] = 'Please Enter valid pickup address';
								return false;
							}
						}
						if(product_len<=0){
							$scope.message[2] = 'Please Select atleast one product';
							return false;
						}
						if($scope.order.ordertype == 2){
							if($scope.order.pickFloor == null || $scope.order.pickFloor == '' ){
								$scope.message[2] = 'Please Enter Floor';
								return false;
							}
							if($scope.order.isAssembly == 1){
								var assemble_product_len = Object.keys($scope.order.assembleProduct).length;
								if(assemble_product_len<=0){
									$scope.message[2] = 'Please select Assebly Product';
									return false;
								}
							}
						}
						if($scope.order.vehicletype != $scope.suggestVehicleType()){
							//if(confirm('Product does not support vehicle type? Do you want to change')){
								var vehicle = new Object();
								var vehicletype = $scope.suggestVehicleType(true);
								$scope.message[2] = 'Vehicle type "'+$scope.resource.vehicletype[vehicletype].text+'" selected';
							//}else{
							//	return false;	
							//}
						}
						$scope.message[2] = '';
						initMap(initMapDirection);
					break;
				case 4:
						if($scope.order.dropname=='' || $scope.order.dropname==null ){
							$scope.message[3] = 'Please Enter Full name';	
							return false;
						}else if($scope.order.dropphone=='' || isNaN($scope.order.dropphone) || ($scope.order.dropphone).length < 6 ){
							$scope.message[3] = 'Please Enter Phone';	
							return false;
						}
						
						if($scope.order.dropAddress=='' || $scope.order.dropAddress==null ){
							$scope.message[3] = 'Please enter drop address';
							return false;
						}
						if($scope.order.ordertype == 2){
							if($scope.order.dropFloor == null || $scope.order.dropFloor == ''){
								$scope.message[3] = 'Please Enter Floors';
								return false;
							}
						}
						
						$scope.getEstimateCharge();
						
					break;
				default:
					break;	
			}
			$scope.openStep = step;
			$scope.complatedStep = step;	
			$scope.init();
		}	// next Step button Over
		
		
		
		//	Place Order 
		$scope.placeOrder = function(){
			var request = $scope.ganarateRequest(true);
			var action = '';
			request.ccdetailid = 2; // For Debug
			if($scope.order.ordertype == 1){
				// Do it your self	
				action = 'doityourself';
			}else if($scope.order.ordertype == 2){
				// Hire a pro
				action = 'hirepro';
			}
			var btn = jQuery('#btnMovirSubmit','#movirapp').button('loading');
			$rootScope.callApi(action,request,function(payload){
				jQuery(btn).button('reset');
				$scope.message[4] = '';
				if(payload.errFlag != 0){ $scope.message[4] = payload.errMsg; return false; }
				$state.go('app.waiting');
			});
		}
		
}]);	//	Order Place Controller over


//	Order History
movirapp.controller('ctrlOrderhistory',['$rootScope','$scope','$state',function($rootScope,$scope,$state){
	$scope.orders = new Object()
	$scope.message = new Object();
	$scope.reorder = new Object();
	$scope.reorder.id = false;
	$scope.reorder.appointmentdate = '';
	$scope.estimateCharge = false;
	$scope.paymentUrl = false;
	
	// Init function
	$scope.init = function(){
		var action = 'getappointments';
		var request = new Object();
		
		request.userid = $rootScope.session.user.userid;
		request.token  = $rootScope.session.user.token;
		
		$rootScope.callApi(action,request,function(payload){
			if(payload.errFlag != 0){ $scope.message[0] = payload.errMsg; return false; }
			var orders = payload.data;
			
			for( i in orders ){
				//	vehicle type class
				if(orders[i].vechicle_type == 1){
					orders[i].vehicle_class = 'minivan';
				}else if(orders[i].vechicle_type == 2){
					orders[i].vehicle_class = 'pickuptruck';
				}else if(orders[i].vechicle_type == 3){
					orders[i].vehicle_class = 'truck';
				}
				
				//	Driver text
				if(orders[i].mas_id == 0){
					orders[i].driver_text = 'No mover assign yet';
				}else{
					orders[i].driver_text = 'Mover : '+orders[i].mas_name;	
				}
				
				//	Date text
				var date = orders[i].appointment_date;	
				date = date.replace(' ','T');
				orders[i].date_text = new Date(date).toLocaleFormat();
				
				//	Label 
				orders[i].status_class = '';
				orders[i].status_text = '';
				if(orders[i].status == 1 || orders[i].status == 2){
					orders[i].status_class = 'label-warning pendding';
					orders[i].status_text = 'PenddingOrder';
				}else if(orders[i].status == 3 || orders[i].status == 4 || orders[i].status == 5){
					orders[i].status_class = 'label-danger cancled';
					orders[i].status_text = 'CanceledOrder';
				}else if(orders[i].status == 6 || orders[i].status == 7 || orders[i].status == 8){
					orders[i].status_class = 'label-info running';
					orders[i].status_text = 'RunningOrder';
				}else if(orders[i].status == 9){
					orders[i].status_class = 'label-success complated';
					orders[i].status_text = 'CompletedOrder';
				}else if(orders[i].status == 10){
					orders[i].status_class = 'label-danger exipry';
					orders[i].status_text = 'ExpiredOrder';
				}
				
				//	Reorder Status
				orders[i].canreorder = false;
				if(orders[i].status == 4 || orders[i].status == 10){
					orders[i].canreorder = true;
				}
				
				//	Amount text
				orders[i].amount_text = orders[i].amount+' ILS';
			}
			$scope.orders = orders;
		})
	}; 
	
	$scope.init();	
	
	$scope.orderDetail = function(orderid){
		$state.go('app.orderdetail',{'orderid':orderid});
	}
	
	//	check appointment date
	$scope.checkAppointmentDate = function(date){
		var action = 'checkappointmentdate';
		var request = new Object();
		request.userid = $rootScope.session.user.userid;
		request.token = $rootScope.session.user.token;
		request.date = date;
		$rootScope.callApi(action,request,function(payload,status){
			$scope.reorder.appointmentdate = '';
			//$scope.message[1] = '';
			$scope.message[1] = payload.errMsg;
			if(payload.errFlag != 0){ $scope.message[1] = payload.errMsg; return false; }
			$scope.reorder.appointmentdate = date;
		});
	}	//	check appointment date Over
	
	//	Get CC detail Id
	$scope.getCcDetailId = function(){
		var btn = jQuery('#btnAddPayment','#movirapp').button('loading');
		var action = 'ganarateccdetail';
		var data = new Object();
		data.userid = $rootScope.session.user.userid;
		data.token= $rootScope.session.user.token;
		
		var payment_modal =	jQuery('#movir_OrderPaymentModal','#movirapp');
		var payment_iframe = jQuery('#iframeOrderPayment','#movirapp')
		if($scope.reorder.ccdetailid){
			payment_iframe.attr('src',$scope.paymentUrl);
			payment_modal.modal('show');
			jQuery(btn).button('reset');
			return false;	
		}
		
		$rootScope.callApi(action,data,function(payload){
			jQuery(btn).button('reset');
			if(payload.errFlag != 0){ 
				$scope.message[4] = payload.errMsg; 
				return false; 
			}
			$scope.reorder.ccdetailid = payload.data.ccdetailid;
			$scope.paymentUrl = payload.data.url;
			payment_iframe.attr('src',$scope.paymentUrl);
			payment_modal.modal('show');
		});
	}	//	Get CC Detail
	
	//	open modal box
	$scope.openDatechecker = function(orderid){
		$scope.message[1] = '';
		$scope.estimateCharge = false;
		$scope.reorder.appointmentdate = '';
		$scope.reorder.id = orderid;
		jQuery('#modalReorder').modal('show');
		//	Datetime picker
		jQuery(function () {
			jQuery('#reorderappointmentdate','#movirapp').datetimepicker({
				format:'MM-DD-YYYY HH:mm:ss',
			}).on('dp.hide',function(e){
				var date = jQuery(this).val();
				$scope.checkAppointmentDate(date);
			});
		});
	}
	
	//	Get Estimate function
	$scope.getEstimate = function(){
		var action = "reuqestreorder";
		var request = new Object();
		request.userid = $rootScope.session.user.userid;
		request.token = $rootScope.session.user.token;
		request.appointment_id = $scope.reorder.id;
		request.datetime = $scope.reorder.appointmentdate;
		var button = jQuery('#getEstimateReorder','#movirapp').button('loading');
		$rootScope.callApi(action,request,function(payload){
			jQuery(button).button('reset');
			$scope.estimateCharge = false;
			$scope.message[1] = '';
			if(payload.errFlag != 0){ $scope.message[1] = payload.errMsg; return false; }
			$scope.estimateCharge = payload.data;
		});
	}
	
	//	Place Order 
	$scope.placeReorder = function(){
		var action = "reorder";
		var request = new Object();
		request.userid = $rootScope.session.user.userid;
		request.token = $rootScope.session.user.token;
		request.appointment_id = $scope.reorder.id;
		request.ccdetailid = $scope.reorder.ccdetailid;
		request.datetime = $scope.reorder.appointmentdate;
		var button = jQuery('#placeReorder','#movirapp').button('loading');
		$rootScope.callApi(action,request,function(payload){
			jQuery(button).button('reset');
			$scope.message[1] = '';
			if(payload.errFlag != 0){ $scope.message[1] = payload.errMsg; return false; }
			jQuery('#modalReorder').modal('hide');
			setInterval(function(){ $state.go('app.waiting'); }, 1000);
			
			/*var appointment_id = payload.data.appointment_id;
			$state.go('app.orderdetail',{'orderid':appointment_id});*/
			
		});
	}

}]);	// Order History

//	Order detail controller
movirapp.controller('ctrlOrderdetail',['$rootScope','$scope','$state','$stateParams',function($rootScope,$scope,$state,$stateParams){
	$scope.order = new Object();
	$scope.message = new Object();
	$scope.init = function(){
		var action = 'getappointment';
		var request = new Object;
		request.userid = $rootScope.session.user.userid;
		request.token  = $rootScope.session.user.token;
		request.appointmentid = $stateParams.orderid;
		$rootScope.callApi(action,request,function(payload){
			if(payload.errFlag != 0){ $state.go('app.orderhistory'); return false; }
			if(payload.data.slave_id != $rootScope.session.user.userid){
				$state.go('app.orderhistory'); 
				return false;
			}
			
			var product_list = new Object();
			var product = payload.data.product;
			for(i in payload.data.product){
				var idx = payload.data.product[i].product_id;
				product_list[idx] = new Object();
				product_list[idx] = payload.data.product[i];
				product_list[idx].index = parseInt(i) + 1;
				product_list[idx].assemble = false;
				
			}
			for(i in payload.data.assemble_product){
				var idx = payload.data.assemble_product[i].product_id;
				product_list[idx].assemble = true;
			}
			$scope.order = payload.data;
			$scope.order.product_list = product_list;
			var date = $scope.order.appointment_date;
			date = date.replace(' ','T')
			$scope.order.date_text = new Date(date).toLocaleFormat();
			
			
			var status_class = '';
			var status_text = '';
			var status = payload.data.status;
			if(status == 1 || status == 2){
				status_class = 'label-warning pendding';
				status_text = 'PenddingOrder';
			}else if(status == 3 || status == 4 || status == 5){
				status_class = 'label-danger cancled';
				status_text = 'CanceledOrder';
			}else if(status == 6 || status == 7 || status == 8){
				status_class = 'label-info running';
				status_text = 'RunningOrder';
			}else if(status == 9){
				status_class = 'label-success complated';
				status_text = 'CompletedOrder';
			}else if(status == 10){
				status_class = 'label-danger exipry';
				status_text = 'ExpiredOrder';
			}
			$scope.order.status_class = status_class;
			$scope.order.status_text = status_text;
		});
		
	}
	$scope.init();
	
	$scope.cancleOrder = function(){
		var action = 'cancleappointment';
		var request = new Object;
		request.userid = $rootScope.session.user.userid;
		request.token  = $rootScope.session.user.token;
		request.appointmentid = $scope.order.appointment_id;
		
		var button = jQuery('#btnCancleOrder').button('loading');
		$rootScope.callApi(action,request,function(payload){
			jQuery(button).button('reset');
			if(payload.errFlag != 0){  
				$scope.message = payload.errMsg;
				return false; 
			}
			$state.go('app.orderhistory');
		});
	}
}]);	//	Order detail controller over


//	Invoice Listing
movirapp.controller('ctrlInvoice',['$rootScope','$scope','$state',function($rootScope,$scope,$state){
	$scope.init = function(){
		var action = 'invoicelist';
		var request = new Object();
		request.userid = $rootScope.session.user.userid;
		request.token  = $rootScope.session.user.token;
		$rootScope.callApi(action,request,function(payload){
			if(payload.errFlag != 0){ $scope.message[0] = payload.errMsg; return false; }
			var invoicelist = payload.data;
			
			for(i in invoicelist){
				invoicelist[i].amount_text = invoicelist[i].amount+' ILS';
				
				invoicelist[i].status_text = '';
				invoicelist[i].status_class = '';
				if(invoicelist[i].status == 1){
					invoicelist[i].status_text = 'Pendding';
					invoicelist[i].status_class = 'label-warning';
				}else if(invoicelist[i].status == 2){
					invoicelist[i].status_text = 'Cancled';
					invoicelist[i].status_class = 'label-info';
				}else if(invoicelist[i].status == 3){
					invoicelist[i].status_text = 'NotPaid';
					invoicelist[i].status_class = 'label-danger';
				}else if(invoicelist[i].status == 4){
					invoicelist[i].status_text = 'Complated';
					invoicelist[i].status_class = 'label-success';
				}
			}
			
			$scope.invoicelist = invoicelist;
			//console.log(payload);
		});
	}
	$scope.init();
	
	$scope.invoiceDetail = function(invoiceid){
		$state.go('app.invoicedetail',{'invoiceid':invoiceid});
		return 
	}
}]);	//	invoice listing complate

//	invoice Detail function 
movirapp.controller('ctrlInvoicedetail',['$rootScope','$scope','$stateParams','$state',function($rootScope,$scope,$stateParams,$state){
	$scope.tip = 0;
	$scope.message = new Object();
	$scope.init = function(){
		var action = 'invoicedetail';
		var request = new Object();
		request.userid = $rootScope.session.user.userid;
		request.token  = $rootScope.session.user.token;
		request.invoiceid = $stateParams.invoiceid;
		$scope.message = new Object();
		$rootScope.callApi(action,request,function(payload){
			if(payload.errFlag != 0){ 
				$state.go('app.invoice');
				$scope.message[0] = payload.errMsg; 
				return false; 
			}
			var invoice = payload.data;
			$scope.tip = parseInt(invoice.tip);
			invoice.vat_amount = 0;
			invoice.transport_charge = 0;
			invoice.without_tip_amount = invoice.amount - $scope.tip; 
			invoice.total_vat_percentage = 100 + parseInt(invoice.vat);
			invoice.transport_charge = ( invoice.without_tip_amount / invoice.total_vat_percentage ) * 100;
			invoice.transport_charge = invoice.transport_charge + parseInt(invoice.discount);
			invoice.vat_amount = (invoice.transport_charge * invoice.vat) / 100;
			
			invoice.vat_amount = (invoice.vat_amount).toFixed(2);
			invoice.transport_charge = (invoice.transport_charge).toFixed(2);
			
			invoice.status_text = '';
			invoice.status_class = '';
			if(invoice.status == 1){
				invoice.status_text = 'Pendding';
				invoice.status_class = 'label-warning';
			}else if(invoice.status == 2){
				invoice.status_text = 'Cancled';
				invoice.status_class = 'label-info';
			}else if(invoice.status == 3){
				invoice.status_text = 'Not Paid';
				invoice.status_class = 'label-danger';
			}else if(invoice.status == 4){
				invoice.status_text = 'Complated';
				invoice.status_class = 'label-success';
			}
			
			
			$scope.invoice = invoice;
		});
	}
	$scope.init();
	
	$scope.makePayment = function(){
		var action = 'customermakepayment';	
		var request = new Object();
		request.userid = $rootScope.session.user.userid;
		request.token  = $rootScope.session.user.token;
		request.appointment_id = $scope.invoice.appointment_id;
		request.tip = $scope.tip;
		
		var button = jQuery('#btnMakepayment').button('loading');
		$rootScope.callApi(action,request,function(payload){
			jQuery(button).button('reset');
			if(payload.errFlag != 0){ 
				$scope.message[0] = payload.errMsg; 
				return false; 
			}
			var invoice = payload.data;
			$state.go('app.rating',{'appointmentid':request.appointment_id});
		});
	}
}]);		//	Invoice detail Over 


//	User Account 
movirapp.controller('ctrlAccount',['$rootScope','$scope',function($rootScope,$scope){
	$scope.message = new Object();
	$scope.init = function(){
		$scope.user = $rootScope.session.user;
	}
	$scope.init();
	
	$scope.update = function(){
		var action = 'updateslave';
		var request = new Object();
		request.userid = $rootScope.session.user.userid;
		request.token = $rootScope.session.user.token;
		request.fname = $scope.user.username;
		
		var button = jQuery('#profileupdate','#movirapp').button('loading');
		$rootScope.callApi(action,request,function(payload){
			jQuery(button).button('reset');
			if(payload.errFlag != 0){
				$scope.message[0] = payload.errMsg;
				return false;
			}
			$rootScope.saveSession();
		});
	}
}]);	//	User Account

//	Driver Rating Controller
movirapp.controller('ctrlRating',['$rootScope','$scope','$state','$stateParams',function($rootScope,$scope,$state,$stateParams){
	$scope.message = new Object();
	$scope.rate = 5;
	$scope.init = function(){
		var action = 'getappointment';
		var request = new Object();
		request.appointmentid = $stateParams.appointmentid;
		$rootScope.callApi(action,request,function(payload){
			if(payload.errFlag != 0){
				$state.go('app.invoice');
				return false;
			}
			var data = payload.data;
			var start_date = data.start_date;
			var complete_date = data.complete_date;
			
			start_date = start_date.replace(' ','T');
			complete_date = complete_date.replace(' ','T');
			
			data.start_date_string = new Date(start_date).toLocaleFormat();
			data.complete_date_string = new Date(complete_date).toLocaleFormat();
			$scope.order = data;
		});
	}
	$scope.init();
	
	$scope.cancle = function(){ $state.go('app.invoice'); }
	
	$scope.sendRating = function(){
		var action = 'driverrating';
		var request = new Object();
		request.userid = $rootScope.session.user.userid;
		request.token = $rootScope.session.user.token;
		request.appointment_id = $scope.order.appointment_id;
		request.rate = $scope.rate;
		if($scope.comment != ''){
			request.comment = $scope.comment;
		}
		
		$rootScope.callApi(action,request,function(payload){
			if(payload.errFlag != 0){
				$scope.message[0] = payload.errMsg;
				return false;
			}
			$state.go('app.invoice');
		});
	}
	
}]);	//	Driver Rating Controller Over


//	Live track url

movirapp.controller('ctrlLivetrack',['$rootScope','$scope','$state',function($rootScope,$scope,$state){
	$scope.message = new Object();
	$scope.markers = [];
	$scope.init = function(){
		var action = 'getappointmenttrack';
		var request = new Object();
		request.userid = $rootScope.session.user.userid;
		request.token = $rootScope.session.user.token;
		$rootScope.callApi(action,request,function(payload){
			if(payload.errFlag != 0){
				$scope.message[0] = payload.errMsg;
				setInterval(function(){ $state.go('app'); },2000);	
				return false;
			}
			var order = payload.data;
			
			order.status_date_string = new Object();
			order.status = parseInt(order.status);
			order.latitude = parseFloat(order.latitude);
			order.longitude = parseFloat(order.longitude);
			for(var i=6; i<= order.status; i++){
				order.status_date_string[i] = $scope.convertDateToString(order.status_time[i]);
			}
			$scope.order = order;
			
			$scope.initMap();
			
			//	If order is hire a pro then check for additional services
			if($scope.order.order_type == 2){
				action = 'getappointment';
				request.appointmentid = $scope.order.appointment_id;
				$rootScope.callApi(action,request,function(payload){
					var product_list = new Object();
					var product = payload.data.product;
					for(i in payload.data.product){
						var idx = payload.data.product[i].product_id;
						product_list[idx] = new Object();
						product_list[idx] = payload.data.product[i];
						product_list[idx].index = parseInt(i) + 1;
						product_list[idx].assemble = false;
						
					}
					for(i in payload.data.assemble_product){
						var idx = payload.data.assemble_product[i].product_id;
						delete (product_list[idx]);
					}
					$scope.product_list = product_list;
				});
			}
		});
	}	
	$scope.init();
	
	$scope.convertDateToString = function(date){
		date = date.replace(' ','T');
		date = new Date(date).toLocaleFormat();
		return date;
	}
	
	$scope.initMap = function(){
		initMap(function(){
			$scope.map = new google.maps.Map(document.getElementById('mapLivetrack'), {
				zoom: 3,
				center: {lat: $scope.order.latitude, lng: $scope.order.longitude}
			});
			$scope.addMarker($scope.order.latitude,$scope.order.longitude,'Driver Location');
			$scope.addMarker($scope.order.pickup_latitude,$scope.order.pickup_longitude,'Pickup Location');
			$scope.addMarker($scope.order.drop_latitude,$scope.order.drop_lonitude,'Drop Location');
		});
	}
	
	$scope.addMarker = function(lat,lng,label) {
		var latlong = new google.maps.LatLng(lat,lng);
		marker = new google.maps.Marker({
			position: latlong,
			map: $scope.map,
			nimation: google.maps.Animation.DROP,
			title:label,
			label:label,
			//description:'Description',
		});
		($scope.markers).push(marker);
	}
	
	//	Additional services
	$scope.submitAdditionalServices = function(){
		var action = 'additionalservice';
		var request = new Object();
		var product_list = jQuery('input[name="assemble_product"]:checked').serializeArray();
		var assemble_product_string = '';
		for(i in product_list){
			var id = product_list[i].value;
			delete($scope.product_list[id]);	// remove added product from list 
			if(assemble_product_string == ''){
				assemble_product_string = id;
			}else{
				assemble_product_string += ','+id;
			}
		}

		request.userid = $rootScope.session.user.userid;
		request.token = $rootScope.session.user.token;
		request.appointment_id = $scope.order.appointment_id;
		request.assemble_product = assemble_product_string;
		
		var button = jQuery('#btnSubmitAdditionalServices','#movirapp').button('loading');
		$rootScope.callApi(action,request,function(payload){
			jQuery(button).button('reset');
			/*if(payload.errFlag != 0){
				$scope.message[1] = payload.errMsg;
				return false;
			}*/
			jQuery('#modalAdditionalServices','#movirapp').modal('hide');
			$scope.message[0] = 'Order Successfully updated';
		})
	}
	
}]);