// JavaScript Document
function getQueryString(obj,parent) {
	var str = [];
	for(var p in obj){
		if(typeof(obj[p]) == 'object'){
			var root_parent = p;
			if(parent){
				root_parent = parent+'['+root_parent+']';
			}
			str.push(getQueryString(obj[p],root_parent));
		}else{
			if(parent){
				str.push(""+parent+"[" + encodeURIComponent(p) + "]=" + encodeURIComponent(obj[p]));
			}else{
				str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
			}
		}
	}
	return str.join("&");
}
/********************	Order Place Screen	********************/
//	Address Autocomplate function 
function initMap(callback){
	if(typeof(callback) == 'function'){ callback(); }
	
	
}

//	Product Autocomplate function 
function autocomplate_product(){
	var products = new Object();
	jQuery('#searchproduct').typeahead({
		ajax: {
			url: ajaxurl,
			timeout: 500,
			displayField: "html",
			valueField:'value',
			triggerLength: 3,
			method: "POST",
			preDispatch: function (query) {
				return {action:'movir_callapi',	api_action: 'getproduct', data : {'userid':1,'token':'1234','string':query}	};
			},	
			preProcess: function (data) {
				var scope = angular.element(document.getElementById('movirapp')).scope();
				scope.$apply(function(){
					scope.$$childHead.message['product'] = '';
				});
				
				if(data.errFlag != 0){
					scope.$apply(function(){
						scope.$$childHead.message['product'] = data.errMsg ;
					}); 
					return false; 
				}
				data = data.data;
				for(i in data){
					data[i]['html'] = data[i]['product_name'];
					data[i]['value'] = data[i]['product_id'];
				}
				products = data;
				return data;
			},
		},
		onSelect: function(item) {
			for(i in products){
				if(products[i]['product_id'] == item.value){
					item = products[i];
				}
			}
			var scope = angular.element(document.getElementById('movirapp')).scope();
			scope.$apply(function(){
				scope.$$childHead.addProduct(item);
			});
		},
	});
}

/* Descktop notification  */

function desktopNotification() {
	var icon = "http://localhost/work/movirtest/admin/images/logo.png";
	// Let's check if the browser supports notifications
	if (!("Notification" in window)) {
		alert("This browser does not support desktop notification");
	}else if (Notification.permission === "granted") {	// Let's check if the user is okay to get some notification
		// If it's okay let's create a notification
		var options = {
			body: "This is the body of the notification",
			icon: icon,
			dir : "ltr"
		};
		var notification = new Notification("Hi there",options);
	}
	// Otherwise, we need to ask the user for permission
	// Note, Chrome does not implement the permission static property
	// So we have to check for NOT 'denied' instead of 'default'
	else if (Notification.permission !== 'denied') {
		Notification.requestPermission(function (permission) {
			// Whatever the user answers, we make sure we store the information
			if (!('permission' in Notification)) {
				Notification.permission = permission;
			}
			
			// If the user is okay, let's create a notification
			if (permission === "granted") {
				var options = {
					body: "This is the body of the notification",
					icon: icon,
					dir : "ltr"
				};
				var notification = new Notification("Hi there",options);
			}
		});
	}
	// At last, if the user already denied any notification, and you
	// want to be respectful there is no need to bother them any more.
}
