<?php
/**
 * @package movir
 */
/**
 *	Plugin Name: Movir
 *	Plugin URI: http://movir.com
 *	Description: Movir Wordpress Plugin
 *	Version: 1.0
 *	Author: White Orange Software
 *	Author URI: http://www.whiteorangesoftware.com
 *	License: 
 *	Text Domain: movir
 */
 
// Configuration Section
define('MOVIR_URL',rtrim(plugin_dir_url( __FILE__ ),'/').'/');
define('MOVIR_PATH',plugin_dir_path( __FILE__ ));
define('DS',DIRECTORY_SEPARATOR);
define('MOVIR_INDEX','index.php');



/**/
define('MOVIR_HOST','whiteglovesme.com');
define('MOVIR_PORT',9000);
define('MOVIR_API_URL','http://'.MOVIR_HOST.'/movirtest/api5.php/');
define('MOVIR_SOCKET_URL','ws://'.MOVIR_HOST.':'.MOVIR_PORT.'/movirtest/client_socket.php/');
/*/
define('MOVIR_HOST','localhost');
define('MOVIR_PORT',9000);
define('MOVIR_API_URL','http://'.MOVIR_HOST.'/work/movir/api6.php/');
define('MOVIR_SOCKET_URL','ws://'.MOVIR_HOST.':'.MOVIR_PORT.'/work/movir/client_socket.php/');
/**/

include(MOVIR_PATH.'functions.php');
include(MOVIR_PATH.'lib/class.form.php');
include(MOVIR_PATH.'lib/helper.debug.php');

$page_name = 'movir';
$cookie = array();
$cookie['name'] = 'movir_token';
$cookie['value'] = session_id();
$cookie['expiry'] = time()+86400*10;
//setcookie($cookie['name'],$cookie['value'],$cookie['expiry']);

add_action('wp_head','movir_ajaxurl');
function movir_ajaxurl() {
	?><script type="text/javascript"> 
		var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>'; 
		var plugin_url = '<?php echo MOVIR_URL; ?>';
		var user = new Object();
		var view_path = plugin_url+'shortcodes/view/';
		var session_id = '<?php echo session_id(); ?>';
		var session = JSON.parse('<?php echo json_encode($_SESSION); ?>');
		var socket_url = '<?php echo MOVIR_SOCKET_URL; ?>';
		var default_language = 'hw';
		//document.cookie="<?php echo $cookie['name'].'='.$cookie['value'].' ; path=/'; ?>";
	</script>
	<?php
}

// Custom Short Code
include(MOVIR_PATH.'shortcodes/index.php');


